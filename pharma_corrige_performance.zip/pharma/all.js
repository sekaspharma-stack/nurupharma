

        let SUPABASE_URL = "";
        let SUPABASE_KEY = "";
        let TENANT_ID = null;
        let TENANT_NAME = "";
 let SESSION_TOKEN = null;
        let dbCloud = null;

        function getStoredConfig() {
            try { return JSON.parse(localStorage.getItem("pharma_supabase_config") || "null"); }
            catch(e) { return null; }
        }

        function saveConfig(url, key, tenantId, tenantName) {
            localStorage.setItem("pharma_supabase_config", JSON.stringify({ url, key, tenantId, tenantName }));
            if (tenantId) localStorage.setItem("pharma_tenant_id", tenantId);
        }

        function clearConfig() {
            localStorage.removeItem("pharma_supabase_config");
            localStorage.removeItem("pharma_user_session");
            localStorage.removeItem("pharma_session_token");
        }

        let supabaseClientUrl = "";
        let supabaseClientKey = "";

        function getOrCreateSupabaseClient(url, key) {
            if (!window.supabase || !window.supabase.createClient) {
                throw new Error("La bibliothèque Supabase n'est pas chargée. Vérifiez votre connexion internet.");
            }
            if (dbCloud && supabaseClientUrl === url && supabaseClientKey === key) {
                return dbCloud;
            }
            const client = window.supabase.createClient(url, key, {
                auth: {
                    persistSession: false,
                    autoRefreshToken: false,
                    detectSessionInUrl: false
                },
                global: {
                    headers: {
                        apikey: key
                    },
                    fetch: async (input, init = {}) => {
                        const headers = new Headers(init.headers || {});
                        headers.set("apikey", key);

                        const sessionToken = SESSION_TOKEN || localStorage.getItem("pharma_session_token");
                        if (sessionToken) headers.set("x-session-id", sessionToken);

                        const tenant = TENANT_ID || localStorage.getItem("pharma_tenant_id");
                        if (tenant) headers.set("x-tenant-id", tenant);

                        // PharmaSys utilise sa session applicative x-session-id,
                        // pas une session Supabase Auth. On conserve donc la clé
                        // publique comme Bearer pour PostgREST/RPC.
                        headers.set("Authorization", `Bearer ${key}`);

                        return fetch(input, { ...init, headers });
                    }
                }
            });
            dbCloud = client;
            supabaseClientUrl = url;
            supabaseClientKey = key;
            return client;
        }

        function initSupabaseClient(sessionToken) {
            const config = getStoredConfig();
            if (!config || !config.url || !config.key) return false;
            SUPABASE_URL = config.url;
            SUPABASE_KEY = config.key;
            TENANT_ID = config.tenantId || null;
            TENANT_NAME = config.tenantName || "";
            SESSION_TOKEN = sessionToken || localStorage.getItem("pharma_session_token") || null;
            getOrCreateSupabaseClient(SUPABASE_URL, SUPABASE_KEY);
            return true;
        }

        async function validerOnboarding(evt) {
            const btn = evt ? evt.currentTarget || evt.target : null;
            const orig = btn ? btn.innerHTML : "";
            if (btn) { btn.disabled = true; btn.innerText = "Connexion..."; }
            try {
                const rawUrl = document.getElementById("onboarding-url").value.trim();
                const key = document.getElementById("onboarding-key").value.trim();
                const tenantName = document.getElementById("onboarding-tenant-name").value.trim() || "Mon Espace";
                const url = rawUrl.replace(/\/+$/, "");
                if (!url || !key) throw new Error("Veuillez saisir l'URL et la clé Supabase.");
                if (!/^https:\/\/[^\s/]+\.supabase\.co$/i.test(url)) {
                    throw new Error("L'URL doit être au format https://xxxxx.supabase.co");
                }
                const response = await fetch(url + "/rest/v1/rpc/setup_tenant", {
                    method: "POST",
                    headers: {
                        "apikey": key,
                        "Authorization": "Bearer " + key,
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify({ p_tenant_name: tenantName, p_admin_code: "admin" })
                });
                let setupResult = null;
                try { setupResult = await response.json(); } catch (_) { setupResult = null; }
                if (!response.ok) {
                    console.error("Supabase setup_tenant:", response.status, setupResult);
                    const message = String((setupResult && (setupResult.message || setupResult.error)) || (response.status + " " + response.statusText));
                    if (response.status === 401 || /invalid api key/i.test(message)) {
                        throw new Error("Clé Supabase invalide. Copiez la clé anon/publishable du projet Supabase (pas l'URL, pas le mot de passe, pas une clé expirée) et réessayez.");
                    }
                    if (response.status === 404 || /function .*setup_tenant.* does not exist|could not find the function/i.test(message)) {
                        throw new Error("La base Supabase n'est pas initialisée : appliquez les migrations du dossier supabase/migrations ou exécutez public/schema.sql, puis réessayez.");
                    }
                    if (response.status === 403 || /permission denied|not authorized/i.test(message)) {
                        throw new Error("Supabase refuse l'appel. Vérifiez les droits EXECUTE de setup_tenant et que la migration d'onboarding a bien été appliquée.");
                    }
                    throw new Error("Supabase a refusé la configuration : " + message);
                }
                const setup = typeof setupResult === "string" ? JSON.parse(setupResult) : setupResult;
                if (!setup || !setup.success || !setup.tenant_id) throw new Error("Configuration impossible : réponse Supabase invalide.");
                const tenantId = setup.tenant_id;
                saveConfig(url, key, tenantId, tenantName);
                if (!initSupabaseClient()) throw new Error("Impossible d'initialiser la connexion Supabase.");
                document.getElementById("onboarding-screen").style.display = "none";
                document.getElementById("login-screen").style.display = "block";
                document.getElementById("login-tenant-name").innerText = TENANT_NAME;
                if (btn) { btn.disabled = false; btn.innerHTML = orig; }
            } catch(e) {
                console.error("Erreur onboarding:", e);
                alert("Erreur de connexion : " + (e.message || e));
                if (btn) { btn.disabled = false; btn.innerHTML = orig; }
            }
        }

        let inventaire = [];
        let historiqueVentes = [];
        let historiqueVentesTop10 = [];
        let mouvementsStock = [];
        let listeUtilisateurs = [];
        let panier = [];
        let utilisateurConnecte = null;
        let totalVentesFc = 0;
        let totalProfitFc = 0;
        let selectedProductIdAst = null;
        let selectedProductIdAdm = null;
        let produitControleActuel = null;
        let controleAnalyseActuel = null;
        let inventaireActuel = null;
        let ticketActuel = null;
        let pageActuelle = 0;
        const produitsParPage = 25;
        let filtreTexteTableau = "";
        let fileAttenteVentes = [];
        let isSyncing = false;
        let offlineDbPromise = null;
        let offlineOperations = [];
        let notificationTimer = null;
        let lastNotificationCount = 0;
        let clients = [];
        let financeTicketsCache = [];
        let financePaymentsCache = [];
        let financeCashCache = [];
        let mouvementsCaisseCache = [];
        let rapportJournalierCache = null;
        let stockAlertThreshold = 2;
        let stockAlertThresholdsByCategory = {};

        function modeHorsLigneForce(){ return localStorage.getItem('pharma_force_offline') === '1'; }
        function reseauDisponible(){ return navigator.onLine && !modeHorsLigneForce(); }
        function basculerModeHorsLigne(){
            const actif=!modeHorsLigneForce();
            localStorage.setItem('pharma_force_offline', actif ? '1' : '0');
            setConnectionStatus(actif ? 'offline' : (navigator.onLine ? 'online' : 'offline'));
            mettreAJourBoutonModeHorsLigne();
            actualiserDiagnosticReseau();
            if(!actif && navigator.onLine) synchroniserFileAttente();
        }
        function mettreAJourBoutonModeHorsLigne(){
            const b=document.getElementById('btn-offline-mode'), d=document.getElementById('diag-toggle-offline');
            const actif=modeHorsLigneForce();
            if(b){ b.textContent=actif?'🟢 Mode local actif':'📴 Hors-ligne'; b.classList.toggle('active',actif); }
            if(d){ d.textContent=actif?'🟢 Désactiver le mode hors connexion':'📴 Forcer le mode hors connexion'; }
        }
        function enregistrerDerniereSync(ok, message){ localStorage.setItem('pharma_last_sync', JSON.stringify({at:new Date().toISOString(),ok:!!ok,message:message||''})); }
        async function testerConnexionReelle(){
            if(!reseauDisponible()) return {ok:false,label:'Hors ligne'};
            const url=(typeof SUPABASE_URL!=='undefined' && SUPABASE_URL)?SUPABASE_URL:null;
            if(!url) return {ok:true,label:'Internet disponible'};
            const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),5000);
            try{ const r=await fetch(url+'/rest/v1/',{method:'HEAD',cache:'no-store',signal:ctrl.signal,headers:{apikey:(typeof SUPABASE_KEY!=='undefined'?SUPABASE_KEY:''),Authorization:`Bearer ${typeof SUPABASE_KEY!=='undefined'?SUPABASE_KEY:''}`}}); clearTimeout(timer); return {ok:r.ok||r.status===401||r.status===404,label:r.ok||r.status===401||r.status===404?'Accessible':'Erreur HTTP '+r.status}; }
            catch(e){clearTimeout(timer);return {ok:false,label:'Inaccessible'};}
        }
        async function actualiserDiagnosticReseau(){
            const browser=navigator.onLine, forced=modeHorsLigneForce();
            const b=document.getElementById('diag-browser-online'), i=document.getElementById('diag-internet'), sp=document.getElementById('diag-supabase'), sw=document.getElementById('diag-sw'), lm=document.getElementById('diag-local-mode'), q=document.getElementById('diag-queue'), st=document.getElementById('diag-storage'), sy=document.getElementById('diag-sync'), tr=document.getElementById('diag-test-result'), pill=document.getElementById('diag-status-pill');
            if(b)b.textContent=browser?'🟢 Oui':'🔴 Non'; if(lm)lm.textContent=forced?'🟠 Forcé':'⚪ Automatique';
            let internet=await testerConnexionReelle(); if(i)i.textContent=internet.label;
            if(sp)sp.textContent=internet.ok?'🟢 Accessible':'🔴 Indisponible';
            if(sw){ if(!('serviceWorker' in navigator)) sw.textContent='🔴 Non supporté'; else { try{const reg=await navigator.serviceWorker.getRegistration('./');sw.textContent=reg&&reg.active?'🟢 Actif':'🟠 En installation';}catch(e){sw.textContent='🔴 Erreur';} } }
            try{offlineOperations=await idbGetOperations();}catch(e){}
            if(q)q.textContent=String(offlineOperations.length||0);
            if(st){let db='IndexedDB : disponible';try{const dbs=await indexedDB.databases();db+=` · ${dbs.length} base(s)`;}catch(e){}st.textContent=db;}
            const last=JSON.parse(localStorage.getItem('pharma_last_sync')||'null'); if(sy)sy.textContent=last?`${last.ok?'✅':'❌'} ${new Date(last.at).toLocaleString('fr-FR')} — ${last.message||''}`:'Aucune synchronisation récente.';
            const effective=reseauDisponible(); if(pill){pill.textContent=effective?'● En ligne':forced?'● Mode local forcé':'● Hors connexion';pill.className='status-pill '+(effective?'ok':'warn');}
            if(tr)tr.textContent=`Test terminé : navigateur=${browser?'OK':'KO'}, Internet=${internet.ok?'OK':'KO'}, Supabase=${internet.ok?'accessible':'inaccessible'}.`;
            mettreAJourBoutonModeHorsLigne();
        }
        async function synchroniserDepuisDiagnostic(){ if(!reseauDisponible()){alert('La synchronisation nécessite Internet et le mode local forcé doit être désactivé.');return;} await synchroniserFileAttente(); enregistrerDerniereSync(true,'Synchronisation manuelle terminée'); await actualiserDiagnosticReseau(); }

        function setConnectionStatus(status) {
            const indicator = document.getElementById("connection-indicator");
            const text = document.getElementById("connection-text");
            const banner = document.getElementById("offline-banner");
            if (!indicator || !text) return;
            indicator.className = status;
            const labels = { online: "En ligne", offline: "Hors-ligne", syncing: "Synchro..." };
            text.textContent = labels[status] || status;
            if (banner) banner.style.display = (status === "offline") ? "block" : "none";
            updateOfflineQueueBadge();
        }

        function openOfflineDb() {
            if (offlineDbPromise) return offlineDbPromise;
            offlineDbPromise = new Promise((resolve, reject) => {
                const req = indexedDB.open("PharmaSysOffline", 2);
                req.onupgradeneeded = () => {
                    const db = req.result;
                    if (!db.objectStoreNames.contains("operations")) {
                        const store = db.createObjectStore("operations", { keyPath: "operation_id" });
                        store.createIndex("created_at", "created_at", { unique:false });
                        store.createIndex("tenant_id", "tenant_id", { unique:false });
                    }
                    if (!db.objectStoreNames.contains("cache")) db.createObjectStore("cache", { keyPath:"key" });
                };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error || new Error("IndexedDB indisponible"));
            });
            return offlineDbPromise;
        }
        async function idbPutOperation(op) {
            const db = await openOfflineDb();
            return new Promise((resolve,reject)=>{ const tx=db.transaction("operations","readwrite"); tx.objectStore("operations").put(op); tx.oncomplete=()=>resolve(); tx.onerror=()=>reject(tx.error); });
        }
        async function idbDeleteOperation(id) {
            const db=await openOfflineDb();
            return new Promise((resolve,reject)=>{const tx=db.transaction("operations","readwrite");tx.objectStore("operations").delete(id);tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});
        }
        async function idbGetOperations() {
            const db=await openOfflineDb();
            return new Promise((resolve,reject)=>{const tx=db.transaction("operations","readonly");const req=tx.objectStore("operations").getAll();req.onsuccess=()=>resolve((req.result||[]).sort((a,b)=>String(a.created_at).localeCompare(String(b.created_at))));req.onerror=()=>reject(req.error);});
        }
        async function idbClearOperations(){const db=await openOfflineDb();return new Promise((resolve,reject)=>{const tx=db.transaction("operations","readwrite");tx.objectStore("operations").clear();tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
        async function idbSetCache(key,value){const db=await openOfflineDb();return new Promise((resolve,reject)=>{const tx=db.transaction("cache","readwrite");tx.objectStore("cache").put({key,value,updated_at:new Date().toISOString()});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
        async function idbGetCache(key){const db=await openOfflineDb();return new Promise((resolve,reject)=>{const tx=db.transaction("cache","readonly");const req=tx.objectStore("cache").get(key);req.onsuccess=()=>resolve(req.result?.value||null);req.onerror=()=>reject(req.error);});}
        async function sauvegarderCacheLocal(){try{await idbSetCache("inventaire",inventaire);await idbSetCache("clients",clients);await idbSetCache("historiqueVentes",historiqueVentes);await idbSetCache("mouvementsStock",mouvementsStock);await idbSetCache("utilisateurs",listeUtilisateurs);}catch(e){console.warn("Cache local:",e.message)}}
        async function restaurerCacheLocal(){try{const [inv,cl,hv,mv,us]=await Promise.all([idbGetCache("inventaire"),idbGetCache("clients"),idbGetCache("historiqueVentes"),idbGetCache("mouvementsStock"),idbGetCache("utilisateurs")]);if(inv)inventaire=inv;if(cl)clients=cl;if(hv)historiqueVentes=hv;if(mv)mouvementsStock=mv;if(us)listeUtilisateurs=us;refreshUI();return !!inv;}catch(e){console.warn("Restauration cache:",e.message);return false}}

        async function migrerAncienneFileAttente() {
            try {
                const old=JSON.parse(localStorage.getItem("pharma_file_attente")||"[]");
                for (const vente of old) {
                    const id=vente.operation_id||("SALE-"+(vente.ticket?.id||crypto.randomUUID()));
                    await idbPutOperation({operation_id:id,operation_type:"VENTE",tenant_id:TENANT_ID,payload:{ticket:vente.ticket,lignes:vente.lignes},created_at:vente.created_at||new Date().toISOString(),status:"PENDING"});
                }
                if (old.length) localStorage.removeItem("pharma_file_attente");
            } catch(e){ console.warn("Migration file offline:",e); }
        }
        async function chargerFileOffline() {
            try { offlineOperations=await idbGetOperations(); updateOfflineQueueBadge(); } catch(e){ console.warn(e); offlineOperations=[]; }
        }
        function updateOfflineQueueBadge() {
            const n=offlineOperations.length;
            const el=document.getElementById("offline-queue-count"); if(el) el.textContent=n?` · ${n} opération(s) en attente`:"";
            const b=document.getElementById("notification-count");
        }
        async function enqueueOfflineOperation(type,payload) {
            const operation_id=(crypto.randomUUID?crypto.randomUUID():("OFF-"+Date.now()+"-"+Math.random().toString(36).slice(2)));
            const op={operation_id,operation_type:type,tenant_id:TENANT_ID,payload,created_at:new Date().toISOString(),status:"PENDING"};
            await idbPutOperation(op); offlineOperations=await idbGetOperations(); updateOfflineQueueBadge(); setConnectionStatus("offline"); return op;
        }
        async function executerOperationOffline(op) {
            const {data,error}=await dbCloud.rpc("executer_operation_offline",{p_operation_id:op.operation_id,p_operation_type:op.operation_type,p_payload:op.payload});
            if(error){
                const msg=error.message||error.details||error.hint||"Erreur Supabase";
                const status=Number(error.status||0);
                if(status===401 || /Invalid API key|JWT|apikey/i.test(msg)){
                    throw new Error("AUTH_API_KEY: URL Supabase et clé anon/publishable incompatibles ou clé invalide.");
                }
                if(status===400 && /Session invalide|expirée|current_tenant/i.test(msg)){
                    throw new Error("AUTH_SESSION: session PharmaSys invalide ou expirée.");
                }
                throw new Error(msg);
            }
            if(!data || data.success!==true) throw new Error(data?.message||"Opération refusée par Supabase");
            return data;
        }
        async function synchroniserFileAttente() {
            if (isSyncing || !dbCloud) return;
            try { offlineOperations=await idbGetOperations(); } catch(e){ return; }
            if (!offlineOperations.length) return;
            if (!reseauDisponible()) { setConnectionStatus("offline"); return; }
            isSyncing=true; setConnectionStatus("syncing");
            const echecs=[];
            for(const op of offlineOperations){
                try { await executerOperationOffline(op); await idbDeleteOperation(op.operation_id); }
                catch(e){
                    const message=e?.message||String(e);
                    console.error("Erreur synchronisation",op.operation_type,message);
                    echecs.push(op);
                    if(/^AUTH_API_KEY:|^AUTH_SESSION:/i.test(message)){
                        enregistrerDerniereSync(false,message);
                        break;
                    }
                }
            }
            offlineOperations=await idbGetOperations(); isSyncing=false;
            if(offlineOperations.length===0){ setConnectionStatus("online"); await chargerDonnees(); }
            else setConnectionStatus(reseauDisponible()?"syncing":"offline");
            updateOfflineQueueBadge();
        }
        window.addEventListener("online",()=>{ setConnectionStatus(modeHorsLigneForce()?"offline":"online"); if(!modeHorsLigneForce()) synchroniserFileAttente(); chargerNotifications(); actualiserDiagnosticReseau(); });
        window.addEventListener("offline",()=>{setConnectionStatus("offline");actualiserDiagnosticReseau();});

        function nombre(valeur) {
            if (valeur === null || valeur === undefined) return 0;
            return parseFloat(valeur.toString().replace(",", ".")) || 0;
        }

        function joursAvantPeremption(datePeremption) {
            if (!datePeremption) return Infinity;
            return (new Date(datePeremption).getTime() - new Date(extraireDateCible()).getTime()) / 86400000;
        }

        function verifierPeremptionProche(datePeremption) {
            if (!datePeremption) return false;
            const dateRefText = extraireDateCible();
            const dateRef = new Date(dateRefText);
            const dateExp = new Date(datePeremption);
            const differenceEnTemps = dateExp.getTime() - dateRef.getTime();
            const differenceEnJours = differenceEnTemps / (1000 * 3600 * 24);
            return differenceEnJours <= 90;
        }

        async function obtenirNomPharmacie() {
            const { data, error } = await dbCloud.from("parametres_pharmacie").select("nom").limit(1).maybeSingle();
            if (error) { console.error(error); return "Sekas pharma"; }
            return (data && data.nom) || "Sekas pharma";
        }

        async function obtenirLogoPharmacie() {
            const { data, error } = await dbCloud.from("parametres_pharmacie").select("logo_url").limit(1).maybeSingle();
            if (error) { console.error(error); return ""; }
            return (data && data.logo_url) || "";
        }

        async function obtenirInfosPharmacie() {
            const { data, error } = await dbCloud.from("parametres_pharmacie").select("*").limit(1).maybeSingle();
            if (error) { console.error(error); return { nom:"Sekas pharma", adresse:"", telephone:"", email:"", rccm:"", slogan:"", logo_url:"" }; }
            return data || { nom:"Sekas pharma", adresse:"", telephone:"", email:"", rccm:"", slogan:"", logo_url:"" };
        }

        function rolePeutGerer(){ return !!utilisateurConnecte && ['admin','Administrateur','responsable','pharmacien'].includes(utilisateurConnecte.role); }

        // Vue des flux : un utilisateur voit ses propres opérations + celles de l'administrateur.
        // L'administrateur voit tous les flux du tenant.
        function estAdministrateur(){
            return !!utilisateurConnecte && ['admin','Administrateur'].includes(utilisateurConnecte.role);
        }
        function nomsAdministrateurs(){
            const noms = new Set();
            (listeUtilisateurs || []).forEach(u => {
                if (['admin','Administrateur'].includes(u.role) && u.nom) noms.add(String(u.nom).trim().toLowerCase());
            });
            if (estAdministrateur() && utilisateurConnecte?.nom) noms.add(String(utilisateurConnecte.nom).trim().toLowerCase());
            return noms;
        }
        function fluxVisiblesPourUtilisateur(rows){
            const source = Array.isArray(rows) ? rows : [];
            if (estAdministrateur()) return source;
            const nom = String(utilisateurConnecte?.nom || '').trim().toLowerCase();
            const admins = nomsAdministrateurs();
            return source.filter(r => {
                const auteur = String(r?.assistant || r?.utilisateur_nom || '').trim().toLowerCase();
                return auteur === nom || admins.has(auteur);
            });
        }

        function chargerNomPharmacie() {
            obtenirNomPharmacie().then(nom => {
                const headerNom = document.getElementById("header-pharmacy-name");
                const inputNom = document.getElementById("pharmacy-name-input");
                if (headerNom) headerNom.innerText = nom;
                if (inputNom) inputNom.value = nom;
            });
        }

        async function fetchAllRows(tableName, selectQuery, gteColumn, gteVal, lteColumn, lteVal) {
            let allData = [];
            let from = 0;
            let to = 999;
            let hasMore = true;
            while (hasMore) {
                let query = dbCloud.from(tableName).select(selectQuery).range(from, to);
                if (gteColumn && gteVal) query = query.gte(gteColumn, gteVal);
                if (lteColumn && lteVal) query = query.lte(lteColumn, lteVal);
                const { data, error } = await query;
                if (error) throw error;
                if (data && data.length > 0) {
                    allData = allData.concat(data);
                    from += 1000;
                    to += 1000;
                    if (data.length < 1000) hasMore = false;
                } else {
                    hasMore = false;
                }
            }
            return allData;
        }

        async function chargerDonnees() {
            if (!dbCloud || !TENANT_ID) return;
            try {
                const { data: inv, error: errInv } = await dbCloud.from("inventaire").select("*").order("nom", { ascending: true });
                if (errInv) throw new Error("Lecture inventaire impossible : " + errInv.message);
                const { data: users, error: errUsers } = await dbCloud.from("utilisateurs").select("*").order("nom", { ascending: true });
                if (errUsers) throw new Error("Lecture utilisateurs impossible : " + errUsers.message);
                inventaire = inv || [];
                const { data: controlesRecents, error: errControles } = await dbCloud
                    .from("controles_inventaire")
                    .select("id,produit_id,stock_physique,ecart,statut,stock_corrige,date_controle")
                    .order("date_controle", { ascending: false });
                if (errControles) throw new Error("Lecture contrôles inventaire impossible : " + errControles.message);
                const dejaVu = new Set();
                (controlesRecents || []).forEach(c => {
                    const pid = String(c.produit_id);
                    if (dejaVu.has(pid)) return;
                    dejaVu.add(pid);
                    const produit = inventaire.find(p => String(p.id) === pid);
                    if (!produit) return;
                    produit.dernier_controle = c.date_controle;
                    produit.statut_inventaire = Number(c.ecart) === 0 ? "CONFORME" : (c.stock_corrige ? "A_SURVEILLER" : "A_SURVEILLER");
                });
                listeUtilisateurs = users || [];
                try { const { data: cData, error: cErr } = await dbCloud.from('clients').select('*').eq('actif',true).order('nom'); if (!cErr) clients = cData || []; } catch (_) { clients = []; }
                remplirClientsVente();
                renderUsersList();

                const nomConnecte = utilisateurConnecte ? utilisateurConnecte.nom : "";
                const estAdmin = rolePeutGerer();

                if (estAdmin) {
                    historiqueVentes = await fetchAllRows("historique_ventes", "*");
                    mouvementsStock = await fetchAllRows("mouvements_stock", "*");
                    historiqueVentesTop10 = historiqueVentes.slice();
                } else {
                    const { data: vAssistant, error: errV } = await dbCloud.from("historique_ventes").select("*").eq("assistant", nomConnecte).order("date", { ascending: false });
                    if (errV) throw new Error("Lecture ventes impossible : " + errV.message);
                    historiqueVentes = vAssistant || [];
                    // Vue personnelle : propres mouvements + mouvements effectués par l'administrateur.
                    const { data: tousLesMouvements, error: errM } = await dbCloud.from("mouvements_stock").select("*").order("created_at", { ascending: false });
                    if (errM) throw new Error("Lecture mouvements impossible : " + errM.message);
                    mouvementsStock = fluxVisiblesPourUtilisateur(tousLesMouvements || []);
                    historiqueVentesTop10 = historiqueVentes.slice();
                }

                await chargerSeuilStockCritique();
                const periode=document.getElementById('filter-mouvements-periode');
                if(periode && !periode.value) periode.value='today';
                const from=document.getElementById('movement-date-from'), to=document.getElementById('movement-date-to');
                if(from && !from.value) from.value=cleDateLocale(new Date());
                if(to && !to.value) to.value=cleDateLocale(new Date());

                totalVentesFc = 0;
                totalProfitFc = 0;
                historiqueVentes.filter(v => v.statut === "VALIDE").forEach(vente => {
                    totalVentesFc += nombre(vente.total);
                    totalProfitFc += nombre(vente.profit);
                });
                const kpiSales = document.getElementById("kpi-sales");
                const kpiProfit = document.getElementById("kpi-profit");
                if (kpiSales) kpiSales.innerText = totalVentesFc.toFixed(2).replace(/\.00$/, "") + " Fc";
                if (kpiProfit) kpiProfit.innerText = totalProfitFc.toFixed(2).replace(/\.00$/, "") + " Fc";
                refreshUI();
            } catch (error) {
                console.error("Erreur chargement des données :", error);
                setConnectionStatus("offline");
                alert("Impossible de charger les données Supabase : " + (error.message || error));
            }
        }

        function refreshUI() {
            try { renderBilanVentes(); } catch(e) { console.error(e); }
            try { renderAdminScreen(); } catch(e) { console.error(e); }
            try { renderUsersList(); } catch(e) { console.error(e); }
            try { renderReappLog(); } catch(e) { console.error(e); }
            try { renderAlphabeticalCatalog(); } catch(e) { console.error(e); }
            try { renderArchives(); } catch(e) { console.error(e); }
            try { chargerNomPharmacie(); } catch(e) { console.error(e); }
            try { renderMouvements(); } catch(e) { console.error(e); }
            try { chargerMouvementsCaisse(); } catch(e) { console.error(e); }
            try { renderTop10Ventes(); } catch(e) { console.error(e); }
            try { renderRupturesStock(); } catch(e) { console.error(e); }
            try { renderRepertoireManquants(); } catch(e) { console.error(e); }
            renderPanier();
        }

        async function loginApp() {
            const code = document.getElementById("login-code").value.trim();
            if (!TENANT_ID) { alert("Aucun espace configur&eacute;. Veuillez reconfigurer l'application."); return; }
            try {
                const { data, error } = await dbCloud.rpc("authenticate_user", { p_code: code, p_tenant_id: TENANT_ID });
                if (error) { alert("Erreur de connexion : " + error.message); return; }
                const result = typeof data === "string" ? JSON.parse(data) : data;
                if (!result || !result.success) { alert(result.message || "Code secret incorrect."); return; }
                const user = result.user;
                const sessionToken = result.session_token;
                utilisateurConnecte = user;
                localStorage.setItem("pharma_user_session", JSON.stringify(user));
                localStorage.setItem("pharma_session_token", sessionToken);
                localStorage.setItem("pharma_session_validated_at", String(Date.now()));
                // Recreate client with session token in header for all subsequent requests
                initSupabaseClient(sessionToken);
                const { data: users } = await dbCloud.from("utilisateurs").select("*").order("nom", { ascending: true });
                if (users) listeUtilisateurs = users;
            document.getElementById("login-code").value = "";
            document.getElementById("login-screen").style.display = "none";
            document.querySelector(".container").style.display = "block";
            document.getElementById("navigation-bar").style.display = "flex";
            document.getElementById("btn-logout-ui").style.display = "block";
            document.getElementById("role-text").innerText = user.nom + " (" + (({admin:'Administrateur',assistant:'Assistant',caissier:'Caissier',pharmacien:'Pharmacien',responsable:'Responsable',lecture:'Consultation'}[user.role] || user.role)) + ")";
            if (rolePeutGerer()) {
                document.getElementById("tab-admin-nav").style.display = "flex";
                const astHint = document.getElementById("ast-click-hint"); if (astHint) astHint.style.display = "block";
            } else {
                document.getElementById("tab-admin-nav").style.display = "none";
                const astHint = document.getElementById("ast-click-hint"); if (astHint) astHint.style.display = "none";
            }
            switchScreen(rolePeutGerer() ? "admin" : "assistant");
            await chargerDonnees();
            demarrerNotifications();
            if(reseauDisponible()) synchroniserFileAttente();
            } catch(e) {
                console.error("Erreur login:", e);
                alert("Erreur de connexion : " + (e.message || e));
            }
        }

        async function logoutApp() {
            // Delete the session from the server
            if (SESSION_TOKEN) {
                try { await dbCloud.from("sessions").delete().eq("id", SESSION_TOKEN); } catch(e) { console.warn(e); }
            }
            utilisateurConnecte = null;
            localStorage.removeItem("pharma_user_session");
            localStorage.removeItem("pharma_session_token");
            SESSION_TOKEN = null;
            initSupabaseClient();
            document.querySelector(".container").style.display = "none";
            document.getElementById("navigation-bar").style.display = "none";
            document.getElementById("btn-logout-ui").style.display = "none";
            document.getElementById("btn-notifications").style.display = "none";
            if(notificationTimer){clearInterval(notificationTimer);notificationTimer=null;}
            document.getElementById("login-screen").style.display = "block";
            document.getElementById("role-text").innerText = "Veuillez vous connecter";
        }

        function modifierConfigSupabase() {
            const newUrl = document.getElementById("settings-supabase-url").value.trim();
            const newKey = document.getElementById("settings-supabase-key").value.trim();
            const newTenantName = document.getElementById("settings-tenant-name-input").value.trim();
            const config = getStoredConfig();
            const url = newUrl || config.url;
            const key = newKey || config.key;
            const tenantName = newTenantName || config.tenantName;
            if (!url || !key) { alert("URL et cl&eacute; requises."); return; }
            saveConfig(url, key, config.tenantId, tenantName);
            initSupabaseClient();
            document.getElementById("settings-tenant-name").innerText = TENANT_NAME;
            alert("Configuration mise &agrave; jour. L'application va recharger les donn&eacute;es.");
            chargerDonnees();
        }

        async function changerTenant() {
            const newTenantName = document.getElementById("settings-tenant-name-input").value.trim() || "Nouvel Espace";
            const config = getStoredConfig();
            if (!config) { alert("Aucune configuration existante."); return; }
            try {
                const testClient = getOrCreateSupabaseClient(config.url, config.key);
                const { data: setupResult, error: errSetup } = await testClient.rpc("setup_tenant", {
                    p_tenant_name: newTenantName,
                    p_admin_code: "admin"
                });
                if (errSetup) throw errSetup;
                const setup = typeof setupResult === "string" ? JSON.parse(setupResult) : setupResult;
                if (!setup || !setup.success) throw new Error("Création impossible.");
                saveConfig(config.url, config.key, setup.tenant_id, newTenantName);
                clearConfig();
                localStorage.setItem("pharma_supabase_config", JSON.stringify({ url: config.url, key: config.key, tenantId: setup.tenant_id, tenantName: newTenantName }));
                initSupabaseClient();
                logoutApp();
                document.getElementById("login-tenant-name").innerText = TENANT_NAME;
                alert("Nouvel espace cr&eacute;&eacute; : " + newTenantName + ". Veuillez vous connecter avec le code admin (par défaut: admin).");
            } catch(e) {
                alert("Erreur cr&eacute;ation espace : " + e.message);
            }
        }

        function reinitialiserConfig() {
            if (!confirm("Voulez-vous vraiment r&eacute;initialiser la configuration ? Vous devrez saisir &agrave; nouveau l'URL et la cl&eacute; Supabase.")) return;
            clearConfig();
            utilisateurConnecte = null;
            document.querySelector(".container").style.display = "none";
            document.getElementById("navigation-bar").style.display = "none";
            document.getElementById("btn-logout-ui").style.display = "none";
            document.getElementById("login-screen").style.display = "none";
            document.getElementById("onboarding-screen").style.display = "block";
        }

        function peuplerChampsConfig() {
            const config = getStoredConfig();
            if (!config) return;
            const elName = document.getElementById("settings-tenant-name");
            if (elName) elName.innerText = config.tenantName || "-";
            const elInputName = document.getElementById("settings-tenant-name-input");
            if (elInputName) elInputName.value = config.tenantName || "";
            const elUrl = document.getElementById("settings-supabase-url");
            if (elUrl) elUrl.value = config.url || "";
        }

        function extraireDateCible() {
            const maintenant = new Date();
            const offset = maintenant.getTimezoneOffset();
            return new Date(maintenant.getTime() - offset * 60000).toISOString().split("T")[0];
        }

        async function afficherSuiviStockMedicament(idProduit, nomMedicament) {
            try {
                const { data: mouvements, error } = await dbCloud.from("mouvements_stock").select("*").eq("produit_id", idProduit).order("created_at", { ascending: false });
                if (error) throw error;
                let html = `<div style="padding:15px;"><h3 style="margin-top:0;color:#1e3d2f;">Suivi de stock : ${nomMedicament || ""}</h3><table style="width:100%;border-collapse:collapse;text-align:left;font-size:14px;"><thead><tr style="background:#f4f4f4;"><th style="padding:10px;">Date</th><th style="padding:10px;">Utilisateur</th><th style="padding:10px;">Operation</th><th style="padding:10px;">Qte</th><th style="padding:10px;">Evolution</th></tr></thead><tbody>`;
                if (!mouvements || mouvements.length === 0) {
                    html += "<tr><td colspan='5' style='padding:10px;text-align:center;color:#777;'>Aucun mouvement.</td></tr>";
                } else {
                    mouvements.forEach(m => {
                        html += `<tr style="border-bottom:1px solid #eee;"><td style="padding:10px;">${m.date}</td><td style="padding:10px;"><b>${m.assistant}</b></td><td style="padding:10px;">${m.type}</td><td style="padding:10px;">${m.quantite}</td><td style="padding:10px;font-weight:bold;">${m.stock_avant} -> ${m.stock_apres}</td></tr>`;
                    });
                }
                html += "</tbody></table><button onclick='this.parentElement.parentElement.remove()' style='margin-top:15px;background:#c5221f;color:white;'>Fermer</button></div>";
                const boiteModale = document.createElement("div");
                boiteModale.id = "modal-suivi-stock";
                boiteModale.style.cssText = "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:white;box-shadow:0 4px 20px rgba(0,0,0,0.3);border-radius:8px;z-index:10000;max-width:90%;width:600px;max-height:80vh;overflow-y:auto;border-top:5px solid #1e3d2f;";
                boiteModale.innerHTML = html;
                const ancienne = document.getElementById("modal-suivi-stock");
                if (ancienne) ancienne.remove();
                document.body.appendChild(boiteModale);
            } catch (error) {
                console.error("Erreur suivi stock:", error.message);
                alert("Impossible de charger le suivi de stock.");
            }
        }

        async function renderPeremptionAlerts(){const el=document.getElementById('admin-peremption-liste');if(!el)return;const arr=inventaire.filter(p=>p.actif!==false&&p.peremption).map(p=>({...p,j:joursAvantPeremption(p.peremption),val:nombre(p.stock)*nombre(p.pua)})).filter(p=>p.j<=180).sort((a,b)=>a.j-b.j);el.innerHTML=arr.length?arr.slice(0,20).map(p=>`<div style="padding:7px;border-bottom:1px solid #fde68a;display:flex;justify-content:space-between;gap:8px;"><span><b>${p.nom}</b><br><small>Exp. ${p.peremption.split('-').reverse().join('/')} · ${nombre(p.stock)} u · ${p.val.toFixed(0)} Fc immobilisés</small></span><b style="color:${p.j<=30?'#dc2626':p.j<=90?'#d97706':'#64748b'};">${p.j<0?'EXPIRÉ':Math.ceil(p.j)+' j'}</b></div>`).join(''):'<p style="color:#718096;">Aucun produit à risque dans les 180 jours.</p>'}

        async function openAdminSubSection(sectionId) {
            document.getElementById("admin-main-menu-grid").style.display = "none";
            document.querySelectorAll(".admin-section").forEach(sec => sec.style.display = "none");
            document.getElementById(sectionId).style.display = "block";
            document.getElementById("btn-back-to-grid").style.display = "block";
            if (sectionId === "sub-admin-finances") { chargerTickets(); chargerAnalyseVentes('mois'); renderTop10Ventes(); renderAdminScreen(); chargerFinanceDashboard(); initialiserDateRapportJournalier(); chargerRapportJournalier().catch(()=>{}); }
            else if (sectionId === "sub-admin-logistique") {
                await renderRupturesStock();
                await renderPeremptionAlerts();
                await renderRepertoireManquants();
                await afficherInventaireEnCours();
                await chargerHistoriqueInventaires();
            }
            else if (sectionId === "sub-admin-parametres") { peuplerChampsConfig(); renderSeuilsStockParCategorie(); }
            window.scrollTo({ top: 0, behavior: "smooth" });
        }

        function closeAdminSubSection() {
            document.querySelectorAll(".admin-section").forEach(sec => sec.style.display = "none");
            document.getElementById("btn-back-to-grid").style.display = "none";
            document.getElementById("admin-main-menu-grid").style.display = "grid";
        }

        async function chargerInfosPharmacie() {
            if (!dbCloud || !TENANT_ID) return;
            const { data, error } = await dbCloud.from("parametres_pharmacie").select("*").eq("tenant_id", TENANT_ID).maybeSingle();
            if (error) { console.error("Erreur paramètres pharmacie :", error); return; }
            if (!data) return;
            const setVal = (id, value) => { const el = document.getElementById(id); if (el) el.value = value || ""; };
            setVal("pharmacy-name-input", data.nom);
            setVal("pharmacy-address", data.adresse);
            setVal("pharmacy-phone", data.telephone);
            setVal("pharmacy-email", data.email);
            setVal("pharmacy-rccm", data.rccm);
            setVal("pharmacy-slogan", data.slogan);
            await chargerSeuilStockCritique();
            const preview = document.getElementById("logo-preview");
            if (preview) preview.innerHTML = data.logo_url ? `<img src="${data.logo_url}" style="width:120px;height:120px;object-fit:contain;border-radius:10px;border:1px solid #ddd;padding:6px;background:white;">` : "";
        }

        async function sauvegarderInfosPharmacie() {
            if (!dbCloud || !TENANT_ID) { alert("Session Supabase non initialisée."); return; }
            const nom = document.getElementById("pharmacy-name-input").value.trim();
            const adresse = document.getElementById("pharmacy-address").value.trim();
            const telephone = document.getElementById("pharmacy-phone").value.trim();
            const email = document.getElementById("pharmacy-email").value.trim();
            const rccm = document.getElementById("pharmacy-rccm").value.trim();
            const slogan = document.getElementById("pharmacy-slogan").value.trim();
            let logoUrl = null;

            try {
                const { data: existing, error: existingError } = await dbCloud.from("parametres_pharmacie")
                    .select("id,logo_url")
                    .eq("tenant_id", TENANT_ID)
                    .maybeSingle();
                if (existingError) throw existingError;
                logoUrl = existing ? existing.logo_url : null;

                const inputLogo = document.getElementById("pharmacy-logo");
                if (inputLogo && inputLogo.files && inputLogo.files.length > 0) {
                    const fichier = inputLogo.files[0];
                    const safeName = fichier.name.replace(/[^a-zA-Z0-9._-]/g, "_");
                    const nomFichier = `${TENANT_ID}/${Date.now()}_${safeName}`;
                    const { error: uploadError } = await dbCloud.storage.from("logos").upload(nomFichier, fichier, { upsert: true, contentType: fichier.type || undefined });
                    if (uploadError) throw new Error("Erreur upload logo : " + uploadError.message + ". Vérifiez que le bucket public 'logos' existe.");
                    const { data: publicData } = dbCloud.storage.from("logos").getPublicUrl(nomFichier);
                    logoUrl = publicData.publicUrl;
                }

                const payload = { nom, adresse, telephone, email, rccm, slogan, logo_url: logoUrl || "", tenant_id: TENANT_ID };
                if (existing) {
                    const { error } = await dbCloud.from("parametres_pharmacie").update(payload).eq("id", existing.id).eq("tenant_id", TENANT_ID);
                    if (error) throw error;
                } else {
                    const { error } = await dbCloud.from("parametres_pharmacie").insert([payload]);
                    if (error) throw error;
                }
                alert("Informations de la pharmacie enregistrées.");
                await chargerInfosPharmacie();
            } catch (error) {
                console.error("Erreur sauvegarde pharmacie :", error);
                alert(error.message || String(error));
            }
        }

        async function exporterDonnees() {
            try {
                const { data: inv } = await dbCloud.from("inventaire").select("*");
                const { data: ventes } = await dbCloud.from("historique_ventes").select("*");
                const { data: mouv } = await dbCloud.from("mouvements_stock").select("*");
                const { data: users } = await dbCloud.from("utilisateurs").select("*");
                const sauvegarde = { version:1, date:new Date().toISOString(), inventaire:inv, historique_ventes:ventes, mouvements_stock:mouv, utilisateurs:users };
                const blob = new Blob([JSON.stringify(sauvegarde, null, 2)], { type:"application/json" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url; a.download = "PharmaSys_Sauvegarde_" + new Date().toISOString().replace(/[:.]/g,"-") + ".json";
                document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
                alert("Sauvegarde exportee.");
            } catch (e) { console.error(e); alert("Erreur : " + e.message); }
        }

        async function importerDonnees(event) {
            const fichier = event.target.files[0];
            if (!fichier) return;
            if (!confirm("Toutes les donnees actuelles seront remplacees. Continuer ?")) { event.target.value = ""; return; }
            try {
                await exporterDonnees();
                const texte = await fichier.text();
                const sauvegarde = JSON.parse(texte);
                if (!sauvegarde.inventaire || !sauvegarde.historique_ventes) throw new Error("Fichier invalide.");
                await dbCloud.from("historique_ventes").delete().neq("id","");
                await dbCloud.from("mouvements_stock").delete().gt("id",0);
                await dbCloud.from("utilisateurs").delete().gt("id",0);
                await dbCloud.from("inventaire").delete().gt("id",0);
                if (sauvegarde.inventaire.length) { sauvegarde.inventaire.forEach(r => r.tenant_id = TENANT_ID); await dbCloud.from("inventaire").insert(sauvegarde.inventaire); }
                if (sauvegarde.utilisateurs && sauvegarde.utilisateurs.length) { sauvegarde.utilisateurs.forEach(r => r.tenant_id = TENANT_ID); await dbCloud.from("utilisateurs").insert(sauvegarde.utilisateurs); }
                if (sauvegarde.historique_ventes.length) { sauvegarde.historique_ventes.forEach(r => r.tenant_id = TENANT_ID); await dbCloud.from("historique_ventes").insert(sauvegarde.historique_ventes); }
                if (sauvegarde.mouvements_stock && sauvegarde.mouvements_stock.length) { sauvegarde.mouvements_stock.forEach(r => r.tenant_id = TENANT_ID); await dbCloud.from("mouvements_stock").insert(sauvegarde.mouvements_stock); }
                await chargerDonnees();
                alert("Donnees restaurees.");
            } catch (err) { console.error(err); alert("Restauration echouee : " + err.message); }
            event.target.value = "";
        }

        async function reinitialiserVentesCloud() {
            if (!utilisateurConnecte || !['admin','Administrateur'].includes(utilisateurConnecte.role)) { alert('Seul l administrateur peut réinitialiser les historiques.'); return; }
            if (!confirm('ATTENTION : cette opération supprime les ventes, tickets, lignes, historique des mouvements et toutes les données financières du tenant. Les médicaments, le stock, les clients, les utilisateurs et les paramètres sont conservés. Continuer ?')) return;
            const codeSecu = prompt('Saisir votre code administrateur pour confirmer :');
            if (codeSecu !== utilisateurConnecte.code) { alert('Code secret incorrect.'); return; }
            try {
                if (!reseauDisponible()) throw new Error('Cette opération critique nécessite une connexion Internet. Désactivez le mode hors connexion pour continuer.');
                const { data, error } = await dbCloud.rpc('reinitialiser_historique_systeme');
                if (error) throw error;
                if (!data || data.success !== true) throw new Error(data?.message || 'Réinitialisation non confirmée.');
                await idbClearOperations();
                offlineOperations=[];
                await chargerFileOffline();
                await chargerDonnees();
                await chargerFinanceDashboard();
                alert('Historique des ventes, tickets et données financières réinitialisés. Médicaments, stock et paramètres conservés.');
            } catch (err) { console.error(err); alert('Erreur lors de la réinitialisation : ' + (err.message || err)); }
        }

        async function enregistrerMouvementCloud(type, produit, quantite, avant, apres, observation, ticket) {
            const maintenant = new Date();
            const fragments = maintenant.toLocaleDateString("fr-FR").split("/");
            const dateFormateeFr = fragments[0] + "/" + fragments[1] + "/" + fragments[2] + " " + maintenant.toLocaleTimeString("fr-FR");
            const mouvement = { date:dateFormateeFr, created_at:maintenant.toISOString(), assistant:utilisateurConnecte.nom, produit_id:Number(produit.id), produit:produit.nom, type:type, quantite:nombre(quantite), stock_avant:nombre(avant), stock_apres:nombre(apres), observation:observation||"", ticket:ticket||null, tenant_id:TENANT_ID };
            const { error } = await dbCloud.from("mouvements_stock").insert([mouvement]);
            if (error) { console.error(error); alert("Erreur mouvements : " + error.message); return false; }
            return true;
        }

        async function saveUserCloud() {
            const idEdit = document.getElementById("user-id-edit").value;
            const nom = document.getElementById("user-name").value.trim();
            const code = document.getElementById("user-code").value.trim();
            const role = document.getElementById("user-role").value;
            if (!nom || !code) { alert("Veuillez remplir le nom et le code."); return; }
            const id = idEdit ? parseInt(idEdit, 10) : null;
            try {
                const payload = { nom:nom, code:code, role:role, actif:true, tenant_id:TENANT_ID };
                if (id !== null) payload.id = id;
                const { error } = await dbCloud.from("utilisateurs").upsert([payload]);
                if (error) throw error;
                alert("Utilisateur enregistre.");
                clearUserForm();
                await chargerDonnees();
            } catch (err) { alert("Erreur : " + err.message); }
        }

        async function toggleUserStatus(id, currentStatus) {
            await dbCloud.from("utilisateurs").update({ actif: !currentStatus }).eq("id", id);
            await chargerDonnees();
        }

        async function deleteUserCloud(id) {
            if (id === 99) { alert("Impossible de supprimer l Administrateur principal."); return; }
            if (confirm("Confirmer la suppression ?")) {
                await dbCloud.from("utilisateurs").delete().eq("id", id);
                await chargerDonnees();
            }
        }

        function editUserForm(id, nom, code, role) {
            document.getElementById("user-id-edit").value = id;
            document.getElementById("user-name").value = nom;
            document.getElementById("user-code").value = code;
            document.getElementById("user-role").value = role;
        }

        function clearUserForm() {
            const idEdit = document.getElementById("user-id-edit");
            const nameInput = document.getElementById("user-name");
            const codeInput = document.getElementById("user-code");
            const roleSelect = document.getElementById("user-role");
            if (idEdit) idEdit.value = "";
            if (nameInput) nameInput.value = "";
            if (codeInput) { codeInput.value = ""; codeInput.setAttribute("type","password"); }
            if (roleSelect) roleSelect.value = "assistant";
        }

        function renderUsersList() {
            const container = document.getElementById("admin-users-list");
            if (!container) return;
            container.innerHTML = "";
            if (!listeUtilisateurs || listeUtilisateurs.length === 0) {
                container.innerHTML = "<p style='color:#718096;text-align:center;padding:10px;'>Aucun personnel.</p>";
                return;
            }
            listeUtilisateurs.forEach(u => {
                const statusLabel = u.actif ? "Actif" : "Bloque";
                container.innerHTML += `<div class="list-item" style="font-size:0.85rem;background:#f1f5f9;padding:8px;margin-bottom:5px;border-radius:6px;"><div><b>${u.nom}</b> (${u.role.toUpperCase()})<br><small>Code: **** | ${statusLabel}</small></div><div style="display:flex;gap:4px;"><button onclick='editUserForm(${u.id}, ${JSON.stringify(u.nom)}, ${JSON.stringify(u.code)}, ${JSON.stringify(u.role)})' style="width:auto;padding:6px 10px;font-size:0.75rem;background:var(--accent-blue);">Edit</button><button onclick='toggleUserStatus(${u.id}, ${u.actif})' style="width:auto;padding:6px 10px;font-size:0.75rem;" class="${u.actif ? "btn-secondary" : "btn-accent"}">${u.actif ? "Bloquer" : "Activer"}</button><button onclick='deleteUserCloud(${u.id})' style="width:auto;padding:6px 10px;font-size:0.75rem;background:var(--danger);">X</button></div></div>`;
            });
        }

        function renderReappLog() {
            const container = document.getElementById("admin-reapp-log");
            if (!container) return;
            container.innerHTML = "";
            const reapps = mouvementsStock.filter(m => m.type === "REAPPRO");
            if (reapps.length === 0) { container.innerHTML = "<p style='color:#718096;text-align:center;'>Aucun reapprovisionnement.</p>"; return; }
            reapps.forEach(r => {
                container.innerHTML += `<div class="list-item" style="font-size:0.85rem;background:#fffbeb;border-left:3px solid var(--warning);padding:8px;margin-bottom:5px;"><div><b>${r.produit}</b><br><small>Le ${r.date}</small><br>Auteur : <b>${r.assistant}</b></div><div style="text-align:right;"><span style="color:#b45309;font-weight:bold;">+ ${parseFloat(r.quantite)} u.</span></div></div>`;
            });
        }

        function normaliserCategorieStock(categorie) {
            const c = String(categorie || "Non classé").trim();
            return c || "Non classé";
        }
        function getSeuilStockCategorie(categorie) {
            const key = normaliserCategorieStock(categorie).toLowerCase();
            const value = stockAlertThresholdsByCategory[key];
            return Number.isFinite(Number(value)) ? Math.max(0, Number(value)) : 2;
        }
        function stockEstCritique(stock, categorie) {
            const qte = nombre(stock);
            if (qte <= 0) return true;
            return qte <= getSeuilStockCategorie(categorie);
        }
        function seuilStockTexte(categorie) {
            const seuil = getSeuilStockCategorie(categorie);
            return seuil > 0 ? String(seuil) : "aucun seuil";
        }
        async function chargerSeuilStockCritique() {
            if (!dbCloud || !TENANT_ID) return;
            try {
                const { data, error } = await dbCloud.from("seuils_stock_categories").select("categorie,seuil").eq("tenant_id", TENANT_ID);
                if (error) throw error;
                stockAlertThresholdsByCategory = {};
                (data || []).forEach(row => { stockAlertThresholdsByCategory[normaliserCategorieStock(row.categorie).toLowerCase()] = Math.max(0, Number(row.seuil) || 0); });
                renderSeuilsStockParCategorie();
                renderRupturesStock();
                renderAlphabeticalCatalog();
            } catch (e) {
                console.warn("Seuils stock par catégorie : valeurs par défaut utilisées", e);
                stockAlertThresholdsByCategory = {};
                renderSeuilsStockParCategorie();
            }
        }
        function renderSeuilsStockParCategorie() {
            const container = document.getElementById("settings-stock-category-thresholds");
            if (!container) return;
            const categories = [...new Set((inventaire || []).filter(p => p.actif !== false).map(p => normaliserCategorieStock(p.categorie)))].sort((a,b) => a.localeCompare(b, "fr"));
            if (!categories.length) { container.innerHTML = "<p style='color:#64748b;'>Aucune catégorie trouvée. Ajoutez d'abord une catégorie aux articles.</p>"; return; }
            container.innerHTML = categories.map(cat => {
                const key = cat.toLowerCase();
                const seuil = Object.prototype.hasOwnProperty.call(stockAlertThresholdsByCategory, key) ? stockAlertThresholdsByCategory[key] : 2;
                return `<div style="display:flex;align-items:center;gap:10px;margin:8px 0;padding:8px;background:#fff;border:1px solid #e5e7eb;border-radius:8px;"><div style="flex:1;font-weight:bold;">${cat}</div><label style="font-size:.8rem;color:#64748b;">Seuil</label><input type="number" min="0" step="1" data-stock-category="${cat.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}" value="${seuil}" style="max-width:90px;margin:0;"></div>`;
            }).join("");
        }
        async function sauvegarderSeuilsStockParCategorie() {
            if (!dbCloud || !TENANT_ID) { alert("Session Supabase non initialisée."); return; }
            const inputs = [...document.querySelectorAll("#settings-stock-category-thresholds input[data-stock-category]")];
            if (!inputs.length) { alert("Aucune catégorie à configurer."); return; }
            try {
                const rows = inputs.map(input => {
                    const categorie = normaliserCategorieStock(input.getAttribute("data-stock-category"));
                    const seuil = Number(input.value);
                    if (!Number.isFinite(seuil) || seuil < 0) throw new Error("Le seuil de « " + categorie + " » doit être supérieur ou égal à 0.");
                    return { tenant_id: TENANT_ID, categorie, seuil: Math.floor(seuil) };
                });
                const { error } = await dbCloud.from("seuils_stock_categories").upsert(rows, { onConflict: "tenant_id,categorie" });
                if (error) throw error;
                stockAlertThresholdsByCategory = {};
                rows.forEach(row => { stockAlertThresholdsByCategory[row.categorie.toLowerCase()] = row.seuil; });
                renderSeuilsStockParCategorie();
                renderRupturesStock();
                renderAlphabeticalCatalog();
                alert("Les seuils d'alerte par catégorie ont été enregistrés.");
            } catch (e) { alert("Impossible d'enregistrer les seuils : " + (e.message || e)); }
        }

        function renderRupturesStock() {
            const container = document.getElementById("admin-ruptures-liste");
            if (!container) return;
            container.innerHTML = "";
            const articlesCritiques = inventaire.filter(p => p.actif !== false && stockEstCritique(p.stock, p.categorie));
            if (articlesCritiques.length === 0) { container.innerHTML = "<p style='color:#047857;text-align:center;padding:10px;'>Aucun medicament en rupture.</p>"; return; }
            articlesCritiques.forEach(p => {
                const qte = nombre(p.stock);
                const badgeText = qte === 0 ? "EPUISE" : qte + " restant";
                const badgeStyle = qte === 0 ? "background:#7f1d1d;color:#fff;" : "background:#b45309;color:#fff;";
                container.innerHTML += `<div class="list-item" style="font-size:0.85rem;background:#fff;border-left:4px solid ${qte === 0 ? "var(--danger)" : "var(--warning)"};padding:8px 12px;margin-bottom:5px;border-radius:4px;cursor:pointer;" onclick='selectProduct(${p.id}, "adm")'><div><b>${p.nom}</b><br><small style="color:#64748b;">Catégorie : ${normaliserCategorieStock(p.categorie)} · Seuil : ${seuilStockTexte(p.categorie)}</small></div><span class="badge" style="${badgeStyle}">${badgeText}</span></div>`;
            });
        }

        function toggleRepertoireManquants() {
            const zone = document.getElementById("zone-repertoire-manquants");
            const btn = document.getElementById("btn-toggle-rep");
            if (zone.style.display === "none") { zone.style.display = "block"; btn.innerText = "Masquer"; renderRepertoireManquants(); }
            else { zone.style.display = "none"; btn.innerText = "Afficher"; }
        }

        function badgeStatut(statut) {
            const styles = {
                "RESOLU": "background:#dcfce7;color:#166534;",
                "JUSTIFIE": "background:#dbeafe;color:#1d4ed8;",
                "A_SUIVRE": "background:#f3e8ff;color:#7e22ce;"
            };
            const labels = { "RESOLU": "Resolu", "JUSTIFIE": "Justifie", "A_SUIVRE": "A suivre" };
            const s = styles[statut] || "background:#fef3c7;color:#92400e;";
            const l = labels[statut] || "A analyser";
            return `<span style="${s}padding:4px 10px;border-radius:20px;font-size:12px;font-weight:bold;">${l}</span>`;
        }

        async function renderRepertoireManquants() {
            const tbody = document.getElementById("table-body-manquants");
            if (!tbody) return;
            tbody.innerHTML = "";
            const filtreInput = document.getElementById("filter-manquants");
            const filtreTexte = filtreInput ? filtreInput.value.toLowerCase().trim() : "";
            const { data, error } = await dbCloud.from("controles_inventaire").select("*").neq("ecart",0).order("date_controle",{ascending:false});
            if (error) { console.error(error); tbody.innerHTML = "<tr><td colspan='9'>Erreur</td></tr>"; return; }
            let ecarts = data || [];
            const pertes = ecarts.filter(c => Number(c.ecart) < 0).reduce((s,c) => s + Math.abs(Number(c.valeur_ecart||0)),0);
            const surplus = ecarts.filter(c => Number(c.ecart) > 0).reduce((s,c) => s + Number(c.valeur_ecart||0),0);
            const totalControles = ecarts.length;
            const aAnalyser = ecarts.filter(c => c.statut === "A_ANALYSER").length;
            const elP = document.getElementById("kpi-pertes"); if (elP) elP.innerText = nombre(pertes) + " Fc";
            const elS = document.getElementById("kpi-surplus"); if (elS) elS.innerText = nombre(surplus) + " Fc";
            const elC = document.getElementById("kpi-controles"); if (elC) elC.innerText = totalControles;
            const elA = document.getElementById("kpi-analyser"); if (elA) elA.innerText = aAnalyser;
            if (filtreTexte) ecarts = ecarts.filter(c => c.produit_nom.toLowerCase().includes(filtreTexte));
            if (ecarts.length === 0) { tbody.innerHTML = "<tr><td colspan='9'>Aucun ecart.</td></tr>"; return; }
            ecarts.forEach(c => {
                const tr = document.createElement("tr");
                tr.innerHTML = `<td>${new Date(c.date_controle).toLocaleString("fr-FR")}</td><td>${c.produit_nom}</td><td>${c.stock_systeme}</td><td>${c.stock_physique}</td><td style="font-weight:bold;color:${c.ecart < 0 ? "var(--danger)" : "var(--success)"};">${c.ecart}</td><td>${c.valeur_ecart||0} Fc</td><td>${badgeStatut(c.statut)}</td><td>${c.auteur||""}</td><td><button onclick='ouvrirAnalyseInventaire(${c.id})' style="background:#2563eb;width:auto;padding:5px 10px;">Analyser</button></td>`;
                tbody.appendChild(tr);
            });
        }

        function filtrerCatalogueTableau(texte) {
            filtreTexteTableau = texte.toLowerCase().trim();
            pageActuelle = 0;
            renderAlphabeticalCatalog();
        }

        function changerPage(direction) {
            pageActuelle += direction;
            if (pageActuelle < 0) pageActuelle = 0;
            renderAlphabeticalCatalog();
        }

        function renderAlphabeticalCatalog() {
            const tbodyAst = document.getElementById("catalog-table-body-ast");
            const tbodyAdm = document.getElementById("catalog-table-body-adm");
            const tfootAst = document.getElementById("catalog-table-foot-ast");
            const tfootAdm = document.getElementById("catalog-table-foot-adm");
            if (tbodyAst) tbodyAst.innerHTML = "";
            if (tbodyAdm) tbodyAdm.innerHTML = "";
            if (tfootAst) tfootAst.innerHTML = "";
            if (tfootAdm) tfootAdm.innerHTML = "";
            let listeFiltree = inventaire.filter(p => p.actif !== false);
            if (filtreTexteTableau !== "") {
                let s = filtreTexteTableau.toLowerCase();
                listeFiltree = listeFiltree.filter(p => p.nom && p.nom.toLowerCase().includes(s));
            }
            let sommePuaTot = 0, sommePvuTot = 0, sommePvevo = 0, sommeBeneficesJ = 0;
            listeFiltree.forEach(p => {
                const ventesDuJour = historiqueVentes.filter(v => v.produit_id === p.id && v.statut === "VALIDE");
                const qteVendue = ventesDuJour.reduce((acc, v) => acc + nombre(v.quantite || 0), 0);
                sommePuaTot += nombre(p.stock) * nombre(p.pua || 0);
                sommePvuTot += nombre(p.stock) * nombre(p.pvu || 0);
                sommePvevo += qteVendue * nombre(p.pvu || 0);
                sommeBeneficesJ += ventesDuJour.reduce((acc, v) => acc + nombre(v.profit || 0), 0);
            });
            const indexDebut = pageActuelle * produitsParPage;
            const produitsAafficher = listeFiltree.slice(indexDebut, indexDebut + produitsParPage);
            const totalPages = Math.ceil(listeFiltree.length / produitsParPage) || 1;
            const txtPage = "Page " + (pageActuelle + 1) + " / " + totalPages;
            if (document.getElementById("page-indicator-ast")) document.getElementById("page-indicator-ast").innerText = txtPage;
            if (document.getElementById("page-indicator-adm")) document.getElementById("page-indicator-adm").innerText = txtPage;
            let compteurLigne = indexDebut + 1;
            produitsAafficher.forEach(p => {
                const ventesDuJour = historiqueVentes.filter(v => v.produit_id === p.id && v.statut === "VALIDE");
                const qteVendue = ventesDuJour.reduce((acc, v) => acc + nombre(v.quantite || 0), 0);
                const beneficeGeneres = ventesDuJour.reduce((acc, v) => acc + nombre(v.profit || 0), 0);
                const puatot = nombre(p.stock) * nombre(p.pua || 0);
                const pvutot = nombre(p.stock) * nombre(p.pvu || 0);
                const pvevo = qteVendue * nombre(p.pvu || 0);
                const estProchePeremption = verifierPeremptionProche(p.peremption);
                const styleNom = estProchePeremption ? "color:#e53e3e;font-weight:bold;" : "";
                const affichageDate = p.peremption ? `<br><small style="color:#718096;">Exp: ${p.peremption.split("-").reverse().join("/")}</small>` : "";
                const statutInv = p.statut_inventaire || "NON_INSPECTE";
                const badgeControle = statutInv === "CONFORME"
                    ? "<span class='badge' style='background:#DCFCE7;color:#166534;padding:6px 10px;'>🟢 Conforme</span>"
                    : statutInv === "A_SURVEILLER"
                        ? "<span class='badge' style='background:#FFEDD5;color:#9A3412;padding:6px 10px;'>🟠 A surveiller</span>"
                        : "<span class='badge' style='background:#E5E7EB;color:#4B5563;padding:6px 10px;'>⚪ Non inspecté</span>";
                let celluleControle = "<td>" + badgeControle + "</td>";
                if (rolePeutGerer()) {
                    celluleControle = `<td><button onclick='lancerControleInventaire(${p.id});event.stopPropagation();' style="width:auto;margin:0;padding:4px 8px;font-size:0.8rem;background:none;border:none;cursor:pointer;">${badgeControle}</button></td>`;
                }
                const trContent = `<td style="color:#64748b;font-weight:bold;">${compteurLigne}</td><td><span style="${styleNom}">${p.nom}</span>${affichageDate}</td><td><span class="badge ${stockEstCritique(p.stock, p.categorie) ? "alert" : "ok"}">${nombre(p.stock)}</span></td><td style="color:#3182ce;background:#ebf8ff;">${nombre(p.pua||0)} Fc</td><td style="color:#38a169;background:#f0fff4;">${puatot.toFixed(2).replace(/\.00$/,"")} Fc</td><td style="color:#3182ce;background:#ebf8ff;">${nombre(p.pvu||0)} Fc</td><td style="color:#38a169;background:#f0fff4;">${pvutot.toFixed(2).replace(/\.00$/,"")} Fc</td><td style="color:#3182ce;background:#e2e8f0;">${pvevo.toFixed(2).replace(/\.00$/,"")} Fc<br><small>(${qteVendue} vendus)</small></td><td style="color:#38a169;background:#f0fff4;">${beneficeGeneres} Fc</td>${celluleControle}`;
                if (tbodyAst) {
                    const tr = document.createElement("tr"); tr.className = "clickable-row"; tr.innerHTML = trContent;
                    if (rolePeutGerer()) { tr.style.cursor = "pointer"; tr.onclick = () => { switchScreen("admin"); openAdminSubSection("sub-admin-logistique"); selectProduct(p.id, "adm"); }; }
                    tbodyAst.appendChild(tr);
                }
                if (tbodyAdm) {
                    const tr = document.createElement("tr"); tr.className = "clickable-row"; tr.style.cursor = "pointer"; tr.innerHTML = trContent; tr.onclick = () => { selectProduct(p.id, "adm"); };
                    tbodyAdm.appendChild(tr);
                }
                compteurLigne++;
            });
            const footContent = `<tr class="total-row"><td colspan="2">TOTAL</td><td>-</td><td style="color:#3182ce;background:#ebf8ff;">-</td><td style="color:#38a169;background:#f0fff4;">${sommePuaTot.toFixed(2).replace(/\.00$/,"")} Fc</td><td style="color:#3182ce;background:#ebf8ff;">-</td><td style="color:#38a169;background:#f0fff4;">${sommePvuTot.toFixed(2).replace(/\.00$/,"")} Fc</td><td style="color:#3182ce;background:#e2e8f0;">${sommePvevo.toFixed(2).replace(/\.00$/,"")} Fc</td><td style="color:#38a169;background:#f0fff4;">${sommeBeneficesJ.toFixed(2).replace(/\.00$/,"")} Fc</td><td>-</td></tr>`;
            if (tfootAst && produitsAafficher.length > 0) tfootAst.innerHTML = footContent;
            if (tfootAdm && produitsAafficher.length > 0) tfootAdm.innerHTML = footContent;
        }

        function lancerControleInventaire(produitId) {
            const producto = inventaire.find(p => p.id == produitId);
            if (!producto) { alert("Produit introuvable"); return; }
            produitControleActuel = producto;
            document.getElementById("controle-modal").style.display = "block";
            document.getElementById("ctrl-produit").innerText = producto.nom;
            document.getElementById("ctrl-stock-theorique").innerText = nombre(producto.stock);
            document.getElementById("ctrl-stock-physique").value = "";
            document.getElementById("ctrl-resultat").style.display = "none";
        }

        function fermerControleInventaire() {
            document.getElementById("controle-modal").style.display = "none";
            produitControleActuel = null;
        }

        async function validerControleInventaire() {
            if (!produitControleActuel) { alert("Aucun produit selectionne"); return; }
            inventaireActuel = await recupererOuCreerInventaireEnCours();
            if (!inventaireActuel) { alert("Impossible de recuperer l inventaire."); return; }
            const producto = produitControleActuel;
            const stockTheorique = nombre(producto.stock);
            const stockPhysique = nombre(document.getElementById("ctrl-stock-physique").value);
            if (isNaN(stockPhysique) || stockPhysique < 0) { alert("Stock physique invalide"); return; }
            const ecart = stockPhysique - stockTheorique;
            const valeurEcart = ecart * nombre(producto.pua);
            try {
                const payload={p_produit_id:producto.id,p_stock_physique:stockPhysique,p_cause:null,p_observation:"Contrôle tournant",p_auteur:utilisateurConnecte.nom};
                if(!reseauDisponible()){producto.stock=stockPhysique;await enqueueOfflineOperation("CONTROLE",payload);fermerControleInventaire();alert("Contrôle enregistré hors-ligne. Il sera synchronisé automatiquement.");return;}
                const { data, error } = await dbCloud.rpc("enregistrer_controle_tournant", payload);
                if (error) throw error;
                if (!data || data.success !== true) throw new Error("Le contrôle n'a pas été confirmé par Supabase.");
                await mettreAJourResumeInventaire(inventaireActuel.id);
                fermerControleInventaire();
                alert(ecart === 0 ? "Controle termine. Stock conforme." : "Ecart detecte. Ajoute aux analyses.");
            } catch (error) { console.error(error); alert("Erreur : " + error.message); }
        }

        async function ouvrirAnalyseInventaire(id) {
            const { data, error } = await dbCloud.from("controles_inventaire").select("*").eq("id", id).single();
            if (error) { console.error(error); alert("Impossible de charger ce controle"); return; }
            controleAnalyseActuel = data;
            document.getElementById("analyse-produit").innerText = data.produit_nom;
            document.getElementById("analyse-systeme").innerText = data.stock_systeme;
            document.getElementById("analyse-reel").innerText = data.stock_physique;
            document.getElementById("analyse-ecart").innerText = data.ecart;
            document.getElementById("analyse-valeur").innerText = data.valeur_ecart + " Fc";
            document.getElementById("analyse-cause").value = data.cause || "Erreur de comptage";
            document.getElementById("analyse-observation").value = data.observation || "";
            document.getElementById("analyse-statut").value = data.statut || "A_SUIVRE";
            const selectAction = document.getElementById("analyse-action-stock");
            selectAction.value = data.stock_corrige ? "CONSERVER" : "CORRIGER";
            selectAction.disabled = !!data.stock_corrige;
            document.getElementById("analyse-inventaire-modal").style.display = "block";
        }

        function fermerAnalyseInventaire() {
            document.getElementById("analyse-inventaire-modal").style.display = "none";
            controleAnalyseActuel = null;
        }

        async function enregistrerAnalyseInventaire() {
            if (!controleAnalyseActuel) { alert("Aucun controle selectionne"); return; }
            const btn = document.querySelector("#analyse-inventaire-modal button[onclick=\"enregistrerAnalyseInventaire()\"]");
            if (btn && btn.disabled) return;
            if (btn) { btn.disabled = true; btn.dataset.originalText = btn.innerText; btn.innerText = "Enregistrement..."; }
            try {
                const cause = document.getElementById("analyse-cause").value;
                const observation = document.getElementById("analyse-observation").value;
                const statut = document.getElementById("analyse-statut").value;
                const actionStock = document.getElementById("analyse-action-stock").value;
                const payload={p_controle_id:controleAnalyseActuel.id,p_cause:cause,p_observation:observation,p_statut:statut,p_corriger_stock:actionStock === "CORRIGER"};
                if(!reseauDisponible()){await enqueueOfflineOperation("ANALYSE_CONTROLE",payload);alert("Analyse enregistrée hors-ligne. Elle sera synchronisée automatiquement.");fermerAnalyseInventaire();return;}
                const { data, error } = await dbCloud.rpc("traiter_controle_tournant", payload);
                if (error) throw error;
                if (!data || data.success !== true) throw new Error("La correction n'a pas été confirmée par Supabase.");
                alert("Analyse enregistree.");
                fermerAnalyseInventaire();
                await chargerDonnees();
            } catch (error) {
                console.error(error);
                alert("Erreur : " + (error.message || error));
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = btn.dataset.originalText || "Enregistrer"; }
            }
        }

        async function recupererOuCreerInventaireEnCours() {
            const { data: inventaireOuvert, error } = await dbCloud.from("inventaires").select("*").eq("statut","EN_COURS").order("date_inventaire",{ascending:false}).limit(1);
            if (error) console.error(error);
            if (inventaireOuvert && inventaireOuvert.length > 0) { inventaireActuel = inventaireOuvert[0]; return inventaireActuel; }
            const { data: nouveau, error: erreurCreation } = await dbCloud.from("inventaires").insert([{ auteur: utilisateurConnecte.nom, statut: "EN_COURS", tenant_id:TENANT_ID }]).select().single();
            if (erreurCreation) { console.error(erreurCreation); alert("Impossible de creer un inventaire."); return null; }
            inventaireActuel = nouveau;
            return inventaireActuel;
        }

        async function mettreAJourResumeInventaire(inventaireId) {
            const { count: totalActifs } = await dbCloud.from("inventaire").select("*",{count:"exact",head:true}).eq("actif",true);
            const { data: controles } = await dbCloud.from("controles_inventaire").select("produit_id,ecart,valeur_ecart").eq("inventaire_id",inventaireId);
            const listeControles = controles || [];
            const produitsControlesUniques = [...new Set(listeControles.map(c => c.produit_id))];
            const nbControles = produitsControlesUniques.length;
            const nbEcarts = listeControles.filter(c => Number(c.ecart) !== 0).length;
            const pertes = listeControles.filter(c => Number(c.ecart) < 0).reduce((s,c) => s + Math.abs(Number(c.valeur_ecart||0)),0);
            const surplus = listeControles.filter(c => Number(c.ecart) > 0).reduce((s,c) => s + Number(c.valeur_ecart||0),0);
            const avancement = totalActifs > 0 ? Number(((nbControles / totalActifs) * 100).toFixed(2)) : 0;
            let nouveauStatut = "EN_COURS";
            let dateCloture = null;
            if (nbControles >= totalActifs && totalActifs > 0) { nouveauStatut = "CLOTURE"; dateCloture = new Date().toISOString(); }
            await dbCloud.from("inventaires").update({ nb_produits_actifs:totalActifs, nb_produits_controles:nbControles, avancement:avancement, nb_ecarts:nbEcarts, pertes:pertes, surplus:surplus, statut:nouveauStatut, date_cloture:dateCloture }).eq("id",inventaireId);
        }

        async function chargerDonneesInventaire(id) {
            const { data: inv, error } = await dbCloud.from("inventaires").select("*").eq("id",id).single();
            if (error) throw error;
            const { data: controles, error: errC } = await dbCloud.from("controles_inventaire").select("*").eq("inventaire_id",id).order("date_controle",{ascending:true});
            if (errC) throw errC;
            return { inventaire: inv, controles: controles || [] };
        }

        async function voirInventaire(id) {
            const modal = document.getElementById("modal-detail-inventaire");
            const contenu = document.getElementById("contenu-detail-inventaire");
            contenu.innerHTML = "Chargement...";
            modal.style.display = "block";
            let inv, controles;
            try { const d = await chargerDonneesInventaire(id); inv = d.inventaire; controles = d.controles; }
            catch(e) { contenu.innerHTML = "Impossible de charger."; return; }
            const pourcentage = inv.nb_produits_actifs > 0 ? Math.round((inv.nb_produits_controles / inv.nb_produits_actifs) * 100) : 0;
            let html = `<div style="margin-bottom:20px;"><div style="font-size:24px;font-weight:bold;color:#065f46;">Inventaire #${inv.id}</div><div style="line-height:1.8;color:#555;"><div>Auteur : <b>${inv.auteur}</b></div><div>Debut : ${new Date(inv.date_inventaire).toLocaleString("fr-FR")}</div><div>Fin : ${inv.date_cloture ? new Date(inv.date_cloture).toLocaleString("fr-FR") : "En cours"}</div></div></div>`;
            html += `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:20px;"><div class="card" style="text-align:center;"><div style="font-size:24px;font-weight:bold;">${inv.nb_produits_actifs||0}</div><div>Actifs</div></div><div class="card" style="text-align:center;"><div style="font-size:24px;font-weight:bold;">${inv.nb_produits_controles||0}</div><div>Controles</div></div><div class="card" style="text-align:center;"><div style="font-size:24px;font-weight:bold;">${inv.nb_ecarts||0}</div><div>Ecarts</div></div></div>`;
            html += `<div style="margin-bottom:15px;"><div style="display:flex;justify-content:space-between;font-weight:bold;margin-bottom:6px;"><span>Progression</span><span>${pourcentage}%</span></div><div style="height:16px;background:#e5e7eb;border-radius:10px;overflow:hidden;"><div style="width:${pourcentage}%;height:100%;background:#16a34a;"></div></div></div>`;
            html += "<div style='overflow-x:auto;'><table class='table'><thead><tr><th>Date</th><th>Medicament</th><th>Theorique</th><th>Physique</th><th>Ecart</th><th>Valeur</th><th>Statut</th></tr></thead><tbody>";
            controles.forEach(c => {
                html += `<tr><td>${new Date(c.date_controle).toLocaleString("fr-FR")}</td><td>${c.produit_nom}</td><td>${c.stock_systeme}</td><td>${c.stock_physique}</td><td style="font-weight:bold;color:${c.ecart<0?"#dc2626":c.ecart>0?"#16a34a":"#374151"};">${c.ecart}</td><td>${nombre(c.valeur_ecart||0)} Fc</td><td>${badgeStatut(c.statut)}</td></tr>`;
            });
            html += "</tbody></table></div>";
            contenu.innerHTML = html;
        }

        function filtrerDetailInventaire() {
            const filtre = document.getElementById("recherche-detail-inventaire").value.toLowerCase();
            document.querySelectorAll("#contenu-detail-inventaire tbody tr").forEach(ligne => {
                ligne.style.display = ligne.innerText.toLowerCase().includes(filtre) ? "" : "none";
            });
        }

        function fermerDetailInventaire() { document.getElementById("modal-detail-inventaire").style.display = "none"; }

        async function afficherInventaireEnCours() {
            const zone = document.getElementById("inventaire-en-cours-info");
            if (!zone) return;
            const { data, error } = await dbCloud.from("inventaires").select("*").eq("statut","EN_COURS").order("date_inventaire",{ascending:false}).limit(1);
            if (error) { console.error(error); return; }
            if (!data || data.length === 0) { zone.innerHTML = "<div style='color:#718096;'>Aucun inventaire en cours.</div>"; return; }
            const inv = data[0];
            const { count: produitsActifs } = await dbCloud.from("inventaire").select("*",{count:"exact",head:true}).eq("actif",true);
            const { data: controles } = await dbCloud.from("controles_inventaire").select("produit_id,ecart,valeur_ecart").eq("inventaire_id",inv.id);
            const liste = controles || [];
            const produitsControles = [...new Set(liste.map(c => c.produit_id))];
            const nbControles = produitsControles.length;
            const pourcentage = produitsActifs > 0 ? Math.round((nbControles / produitsActifs) * 100) : 0;
            const nbEcarts = liste.filter(c => Number(c.ecart) !== 0).length;
            const pertes = liste.filter(c => Number(c.ecart) < 0).reduce((s,c) => s + Math.abs(Number(c.valeur_ecart||0)),0);
            const surplus = liste.filter(c => Number(c.ecart) > 0).reduce((s,c) => s + Number(c.valeur_ecart||0),0);
            zone.innerHTML = `<div style="line-height:1.9;"><div>Inventaire #${inv.id}</div><div>Debut : ${new Date(inv.date_inventaire).toLocaleString("fr-FR")}</div><div>Auteur : ${inv.auteur}</div><hr><div>Actifs : ${produitsActifs}</div><div>Controles : ${nbControles} / ${produitsActifs}</div><div>Avancement : ${pourcentage}%</div><div>Ecarts : ${nbEcarts}</div><div>Pertes : ${nombre(pertes)} Fc</div><div>Surplus : ${nombre(surplus)} Fc</div><div style="margin-top:12px;height:14px;background:#e5e7eb;border-radius:8px;overflow:hidden;"><div style="width:${pourcentage}%;height:100%;background:#16a34a;"></div></div></div>`;
        }

        async function chargerHistoriqueInventaires() {
            const tbody = document.getElementById("table-body-historique-inventaires");
            if (!tbody) return;
            tbody.innerHTML = "";
            const filtre = (document.getElementById("filter-historique-inventaire") ? document.getElementById("filter-historique-inventaire").value : "").toLowerCase().trim();
            const { data, error } = await dbCloud.from("inventaires").select("*").order("date_inventaire",{ascending:false});
            if (error) { console.error(error); tbody.innerHTML = "<tr><td colspan='10'>Erreur</td></tr>"; return; }
            let inventaires = data || [];
            if (filtre) inventaires = inventaires.filter(inv => String(inv.id).includes(filtre) || (inv.auteur||"").toLowerCase().includes(filtre));
            if (inventaires.length === 0) { tbody.innerHTML = "<tr><td colspan='10'>Aucun inventaire.</td></tr>"; return; }
            inventaires.forEach(inv => {
                const tr = document.createElement("tr");
                const statut = inv.statut === "CLOTURE" ? "<span style='color:#16a34a;'>Cloture</span>" : "<span style='color:#2563eb;'>En cours</span>";
                tr.innerHTML = `<td>#${inv.id}</td><td>${new Date(inv.date_inventaire).toLocaleString("fr-FR")}</td><td>${inv.date_cloture ? new Date(inv.date_cloture).toLocaleString("fr-FR") : "-"}</td><td>${inv.nb_produits_actifs||0}</td><td>${inv.nb_produits_controles||0}</td><td>${inv.nb_ecarts||0}</td><td>${nombre(inv.pertes||0)} Fc</td><td>${nombre(inv.surplus||0)} Fc</td><td>${statut}</td><td><button onclick='voirInventaire(${inv.id})' style="background:#2563eb;width:auto;padding:5px 10px;">Voir</button></td>`;
                tbody.appendChild(tr);
            });
        }

        function searchProduct(query, mode) {
            const resultsDiv = document.getElementById(mode + "-search-results");
            if (!query.trim()) { resultsDiv.style.display = "none"; return; }
            const cleanQuery = query.toLowerCase();
            const filtered = inventaire.filter(p => p.actif !== false && p.nom && p.nom.toLowerCase().includes(cleanQuery)).slice(0, 5);
            if (filtered.length === 0) { resultsDiv.innerHTML = "<div style='padding:10px;color:#718096;'>Aucun produit</div>"; resultsDiv.style.display = "block"; return; }
            resultsDiv.innerHTML = "";
            filtered.forEach(p => {
                const row = document.createElement("div");
                row.innerHTML = "<span>" + p.nom + "</span> (Stock: " + nombre(p.stock) + ")";
                row.onclick = () => selectProduct(p.id, mode);
                resultsDiv.appendChild(row);
            });
            resultsDiv.style.display = "block";
        }

        function selectProduct(id, mode) {
            const resultsDiv = document.getElementById(mode + "-search-results");
            if (resultsDiv) resultsDiv.style.display = "none";
            const searchInput = document.getElementById(mode + "-search");
            if (searchInput) searchInput.value = "";
            const produit = inventaire.find(p => p.id === id);
            if (!produit) return;
            if (mode === "ast") {
                selectedProductIdAst = id;
                document.getElementById("ast-selected-area").style.display = "block";
                document.getElementById("ast-selected-name").innerText = produit.nom;
                if (verifierPeremptionProche(produit.peremption)) document.getElementById("ast-selected-name").style.color = "var(--danger)";
                else document.getElementById("ast-selected-name").style.color = "var(--primary-dark)";
                document.getElementById("stock-hint").innerText = "En stock : " + nombre(produit.stock) + " | P.V.U : " + nombre(produit.pvu) + " Fc" + (produit.peremption ? " | Perim. : " + produit.peremption.split("-").reverse().join("/") : "");
            } else if (mode === "adm") {
                selectedProductIdAdm = id;
                showAdminFocusCard(produit);
                document.getElementById("adm-focus-card").scrollIntoView({ behavior:"smooth", block:"center" });
            }
        }

        function showAdminFocusCard(produit) {
            document.getElementById("adm-focus-card").style.display = "block";
            document.getElementById("focus-nom").innerText = produit.nom;
            document.getElementById("focus-stock").innerText = nombre(produit.stock);
            document.getElementById("focus-input-pua").value = produit.pua;
            document.getElementById("focus-input-pvu").value = produit.pvu;
            if (document.getElementById("focus-input-categorie")) document.getElementById("focus-input-categorie").value = produit.categorie || "Non classé";
            document.getElementById("focus-input-peremption").value = produit.peremption || "";
            document.getElementById("focus-input-reapp").value = "";
            const badge = document.getElementById("focus-badge");
            if (verifierPeremptionProche(produit.peremption)) { badge.innerText = "Peremption proche !"; badge.className = "badge alert"; document.getElementById("focus-nom").style.color = "var(--danger)"; }
            else if (stockEstCritique(produit.stock, produit.categorie)) { badge.innerText = "Reappro necessaire"; badge.className = "badge alert"; document.getElementById("focus-nom").style.color = "var(--primary-dark)"; }
            else { badge.innerText = "Stock Ok"; badge.className = "badge ok"; document.getElementById("focus-nom").style.color = "var(--primary-dark)"; }
        }

        function ajouterAuPanier() {
            if (!selectedProductIdAst) return;
            const produit = inventaire.find(p => p.id == selectedProductIdAst);
            if (!produit) return;
            const qty = nombre(document.getElementById("sale-qty").value);
            if (isNaN(qty) || qty <= 0) { alert("Quantite incorrecte."); return; }
            if (qty > nombre(produit.stock)) { alert("Stock insuffisant."); return; }
            const existe = panier.find(l => l.id == produit.id);
            if (existe) {
                if (existe.quantite + qty > nombre(produit.stock)) { alert("Stock insuffisant."); return; }
                existe.quantite += qty;
            } else {
                panier.push({ id:produit.id, nom:produit.nom, pua:nombre(produit.pua), pvu:nombre(produit.pvu), quantite:qty, stock:nombre(produit.stock) });
            }
            renderPanier();
            document.getElementById("sale-qty").value = 1;
            document.getElementById("ast-selected-area").style.display = "none";
            selectedProductIdAst = null;
        }

        function actualiserPaiementVente() {
            const mode = document.getElementById('sale-payment-mode')?.value || 'ESPECES';
            const clientArea = document.getElementById('sale-client-area');
            const mixte = document.getElementById('sale-mixte-area');
            const hint = document.getElementById('sale-payment-hint');
            if (clientArea) clientArea.style.display = (mode === 'CREDIT' || mode === 'MIXTE') ? 'block' : 'none';
            if (mixte) mixte.style.display = mode === 'MIXTE' ? 'grid' : 'none';
            if (hint) hint.textContent = mode === 'CREDIT' ? 'La totalité sera portée au crédit du client.' : mode === 'MIXTE' ? 'Répartissez exactement le total entre les modes.' : 'Paiement comptant';
            remplirClientsVente();
        }
        function remplirClientsVente() {
            ['sale-client-id','credit-client-id'].forEach(id => { const el=document.getElementById(id); if(!el)return; const current=el.value; el.innerHTML=(id==='sale-client-id'?'<option value="">Sélectionner un client</option>':''); clients.forEach(c=>{const o=document.createElement('option');o.value=c.id;o.textContent=c.nom+(c.telephone?' — '+c.telephone:'');el.appendChild(o)}); if(current)el.value=current; });
        }
        // Compatibilité : validerPanier() utilise cet ancien nom.
        function construirePaiementsVente(total) { return construirePaiements(total); }

        function construirePaiements(total) {
            const mode = document.getElementById('sale-payment-mode')?.value || 'ESPECES';
            const clientId = document.getElementById('sale-client-id')?.value || null;
            if (mode === 'CREDIT') { if(!clientId) throw new Error('Sélectionnez un client pour une vente à crédit.'); return [{mode:'CREDIT',montant:Number(total),client_id:Number(clientId)}]; }
            if (mode === 'MIXTE') {
                const parts=[['ESPECES','pay-cash'],['MOBILE_MONEY','pay-mobile'],['CARTE','pay-card'],['CREDIT','pay-credit']].map(([m,id])=>({mode:m,montant:Number(document.getElementById(id)?.value||0)})).filter(x=>x.montant>0);
                const credit=parts.find(x=>x.mode==='CREDIT'); if(credit){if(!clientId)throw new Error('Sélectionnez un client pour la part à crédit.');credit.client_id=Number(clientId);}
                const sum=parts.reduce((a,x)=>a+x.montant,0); if(Math.abs(sum-total)>0.01)throw new Error('La répartition des paiements doit être exactement égale au total.'); return parts;
            }
            return [{mode:mode,montant:Number(total)}];
        }
        async function creerClientRapide(){
            const nom=prompt('Nom du client :'); if(!nom)return; const telephone=prompt('Téléphone (optionnel) :')||'';
            try{const {data,error}=await dbCloud.from('clients').insert([{nom:nom.trim(),telephone,tenant_id:TENANT_ID}]).select().single();if(error)throw error;clients.push(data);remplirClientsVente();const el=document.getElementById('sale-client-id');if(el)el.value=data.id;alert('Client créé.');}catch(e){alert('Impossible de créer le client : '+e.message)}
        }
        function ouvrirEnregistrementCaisse(){document.getElementById('cash-entry-modal').style.display='block'}
        function fermerMouvementCaisse(){document.getElementById('cash-entry-modal').style.display='none'}
        async function enregistrerMouvementCaisse(){
            const amount=Number(document.getElementById('cash-entry-amount').value||0); if(amount<=0){alert('Montant invalide.');return}
            const payload={p_type:document.getElementById('cash-entry-type').value,p_montant:amount,p_mode:'ESPECES',p_motif:document.getElementById('cash-entry-label').value||'',p_assistant:utilisateurConnecte?.nom||'Système'};
            try{if(!reseauDisponible()){await enqueueOfflineOperation('CAISSE',payload);fermerMouvementCaisse();alert('Mouvement de caisse enregistré hors-ligne.');return;} const {error}=await dbCloud.rpc('enregistrer_mouvement_caisse',payload);if(error)throw error;fermerMouvementCaisse();await chargerFinanceDashboard();alert('Mouvement de caisse enregistré.')}catch(e){alert('Erreur caisse : '+e.message)}
        }
        function ouvrirPaiementCredit(){remplirClientsVente();document.getElementById('credit-payment-modal').style.display='block'}
        function fermerPaiementCredit(){document.getElementById('credit-payment-modal').style.display='none'}
        async function enregistrerPaiementCredit(){
            const cid=Number(document.getElementById('credit-client-id').value||0), amount=Number(document.getElementById('credit-payment-amount').value||0); if(!cid||amount<=0){alert('Client et montant obligatoires.');return}
            const payload={p_client_id:cid,p_montant:amount,p_mode:'ESPECES',p_observation:document.getElementById('credit-payment-note').value||'',p_assistant:utilisateurConnecte?.nom||'Système'};
            try{if(!reseauDisponible()){await enqueueOfflineOperation('PAIEMENT_CREDIT',payload);fermerPaiementCredit();alert('Paiement de crédit enregistré hors-ligne.');return;} const {error}=await dbCloud.rpc('enregistrer_paiement_credit',payload);if(error)throw error;fermerPaiementCredit();await chargerFinanceDashboard();alert('Paiement enregistré.')}catch(e){alert('Erreur paiement : '+e.message)}
        }

        function lirePeriodeFinance(){
            const debut=document.getElementById('finance-date-debut')?.value||'';
            const fin=document.getElementById('finance-date-fin')?.value||'';
            if((debut&&!fin)||(!debut&&fin)) throw new Error('Sélectionnez les deux dates pour un audit personnalisé.');
            if(debut&&fin&&debut>fin) throw new Error('La date de début doit être antérieure ou égale à la date de fin.');
            return {debut,fin};
        }
        async function appliquerAuditFinance(){
            try{ lirePeriodeFinance(); await chargerFinanceDashboard(); await chargerAnalyseVentes('custom'); }catch(e){alert(e.message)}
        }
        async function chargerFinanceDashboard(){
            if(!dbCloud)return; const k=document.getElementById('finance-kpi-grid'); if(k)k.innerHTML='<div class="card">Chargement des indicateurs...</div>';
            try{
                const periode=lirePeriodeFinance();
                let tq=dbCloud.from('tickets').select('*').eq('statut','VALIDE');
                let pq=dbCloud.from('paiements').select('*');
                let cq=dbCloud.from('mouvements_caisse').select('*').order('created_at',{ascending:false});
                if(periode.debut){tq=tq.gte('date',periode.debut).lte('date',periode.fin);const finIso=periode.fin+'T23:59:59';pq=pq.gte('created_at',periode.debut+'T00:00:00').lte('created_at',finIso);cq=cq.gte('created_at',periode.debut+'T00:00:00').lte('created_at',finIso);}
                const [tRes,pRes,cRes]=await Promise.all([tq,pq,cq]);
                if(tRes.error)throw tRes.error; if(pRes.error)throw pRes.error; if(cRes.error)throw cRes.error;
                financeTicketsCache=tRes.data||[]; financePaymentsCache=pRes.data||[]; financeCashCache=cRes.data||[];
                const ca=financeTicketsCache.reduce((s,t)=>s+nombre(t.montant_total),0), marge=financeTicketsCache.reduce((s,t)=>s+nombre(t.benefice_total),0), n=financeTicketsCache.length, panier=n?ca/n:0;
                const stockValue=inventaire.filter(p=>p.actif!==false).reduce((s,p)=>s+nombre(p.stock)*nombre(p.pua),0), credit=financeTicketsCache.reduce((s,t)=>s+nombre(t.montant_credit),0)-financePaymentsCache.filter(p=>p.ticket_id==null&&p.client_id).reduce((s,p)=>s+nombre(p.montant),0);
                const crit=inventaire.filter(p=>p.actif!==false&&stockEstCritique(p.stock, p.categorie)).length, exp=inventaire.filter(p=>p.actif!==false&&p.peremption&&((new Date(p.peremption)-new Date())/86400000)<=90).length;
                const margePct=ca?marge/ca*100:0;
                if(k)k.innerHTML=[['💰 CA net',ca.toFixed(0)+' Fc'],['📈 Marge brute',marge.toFixed(0)+' Fc'],['%',margePct.toFixed(1)+' %'],['🧾 Tickets',n],['🛒 Panier moyen',panier.toFixed(0)+' Fc'],['📦 Stock immobilisé',stockValue.toFixed(0)+' Fc'],['💳 Crédits',Math.max(0,credit).toFixed(0)+' Fc'],['🔴 Ruptures',crit],['⏳ Péremptions <90j',exp]].map(x=>`<div class="card" style="margin:0;text-align:center;background:#fff;"><div style="font-size:.72rem;color:#64748b;font-weight:700;">${x[0]}</div><div style="font-size:1.25rem;font-weight:800;margin-top:5px;">${x[1]}</div></div>`).join('');
                renderCashDashboard(); renderCreditDashboard(); renderBriefing(); renderSmartReorder(); renderForecast(); renderAnomalies(); chargerTopsAvances('ventes');
            }catch(e){console.error(e);if(k)k.innerHTML='<div class="card" style="color:#b91c1c;">Impossible de charger les finances : '+e.message+'</div>'}
        }

        function renderCashDashboard(){
            const el=document.getElementById('cash-dashboard'); if(!el)return;
            const total=financeCashCache.reduce((s,m)=>s+(m.type==='ENTREE'?1:-1)*nombre(m.montant),0);
            const byMode={};
            financeCashCache.forEach(m=>{const k=m.mode||'ESPECES';byMode[k]=(byMode[k]||0)+(m.type==='ENTREE'?1:-1)*nombre(m.montant)});
            const remboursements=financeCashCache.filter(m=>m.nature==='REMBOURSEMENT').reduce((s,m)=>s+nombre(m.montant),0);
            el.innerHTML=`<div style="font-size:1.7rem;font-weight:800;">Solde net caisse : ${total.toFixed(0)} Fc</div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px;margin-top:10px;">${Object.entries(byMode).map(([m,v])=>`<div style="background:#f8fafc;padding:8px;border-radius:8px;"><b>${m.replace('_',' ')}</b><br>${v.toFixed(0)} Fc</div>`).join('')}</div>
            <div style="margin-top:10px;padding:9px;background:#fff7ed;border-radius:8px;"><b>Remboursements :</b> ${remboursements.toFixed(0)} Fc · <b>Écritures :</b> ${financeCashCache.length}</div>`;
        }

        function dateLocaleMouvement(m){
            if(m?.created_at){ const d=new Date(m.created_at); if(!Number.isNaN(d.getTime())) return d; }
            const txt=String(m?.date||'').trim();
            const match=txt.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:\s+(\d{2}):(\d{2})(?::(\d{2}))?)?/);
            if(match){ const d=new Date(Number(match[3]),Number(match[2])-1,Number(match[1]),Number(match[4]||0),Number(match[5]||0),Number(match[6]||0)); if(!Number.isNaN(d.getTime())) return d; }
            return null;
        }
        function cleDateLocale(d){ const x=new Date(d); return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`; }
        function periodeMouvements(){
            const mode=document.getElementById('filter-mouvements-periode')?.value||'today';
            const now=new Date(); const debut=new Date(now.getFullYear(),now.getMonth(),now.getDate()); let fin=new Date(debut); fin.setHours(23,59,59,999);
            if(mode==='yesterday'){ debut.setDate(debut.getDate()-1); fin=new Date(debut); fin.setHours(23,59,59,999); }
            else if(mode==='week'){ const jour=(debut.getDay()+6)%7; debut.setDate(debut.getDate()-jour); fin=new Date(debut); fin.setDate(fin.getDate()+6); fin.setHours(23,59,59,999); }
            else if(mode==='month'){ debut.setDate(1); fin=new Date(debut.getFullYear(),debut.getMonth()+1,0,23,59,59,999); }
            else if(mode==='last7'){ debut.setDate(debut.getDate()-6); }
            else if(mode==='custom'){
                const from=document.getElementById('movement-date-from')?.value; const to=document.getElementById('movement-date-to')?.value;
                if(from) { const a=new Date(from+'T00:00:00'); if(!Number.isNaN(a.getTime())) debut.setTime(a.getTime()); }
                if(to) { const b=new Date(to+'T23:59:59.999'); if(!Number.isNaN(b.getTime())) fin.setTime(b.getTime()); }
            }
            return {debut,fin};
        }
        function mouvementsDansPeriode(rows){ const {debut,fin}=periodeMouvements(); return (rows||[]).filter(m=>{const d=dateLocaleMouvement(m);return d&&d>=debut&&d<=fin;}); }
        function changerPeriodeMouvements(mode){
            const box=document.getElementById('movement-custom-dates');
            if(box) box.style.display=mode==='custom'?'grid':'none';
            if(mode==='custom'){
                const today=cleDateLocale(new Date());
                const from=document.getElementById('movement-date-from'),to=document.getElementById('movement-date-to');
                if(from&&!from.value)from.value=today; if(to&&!to.value)to.value=today;
            }
            renderMouvementsParPeriode();
        }
        function renderMouvementsParPeriode(){ renderMouvements(); renderMouvementsCaisse(); }
        async function chargerMouvementsCaisse(){
            if(!dbCloud)return;
            try{
                const {data,error}=await dbCloud.from('mouvements_caisse').select('*').order('created_at',{ascending:false});
                if(error)throw error;
                // Même règle de visibilité : admin = tout, autres = soi + administrateurs.
                mouvementsCaisseCache=fluxVisiblesPourUtilisateur(data||[]);
                renderMouvementsCaisse();
            }catch(e){console.error(e);const el=document.getElementById('shared-liste-mouvements-caisse');if(el)el.innerHTML=`<p style="color:#b91c1c;">Impossible de charger la caisse : ${e.message}</p>`;}
        }

        function renderMouvementsCaisse(){
            const el=document.getElementById('shared-liste-mouvements-caisse'); if(!el)return;
            const filtre=(document.getElementById('filter-mouvements')?.value||'').toLowerCase().trim();
            let arr=mouvementsDansPeriode(mouvementsCaisseCache);
            if(filtre)arr=arr.filter(m=>[m.mode,m.type,m.nature,m.motif,m.assistant,m.ticket_id,m.reference_id].some(x=>String(x||'').toLowerCase().includes(filtre)));
            const k=document.getElementById('movement-kpi-cash');
            const sol=arr.reduce((s,m)=>s+(m.type==='ENTREE'?1:-1)*nombre(m.montant),0);
            if(k)k.innerHTML=`Caisse<b>${sol.toFixed(0)} Fc</b>`;
            const r=document.getElementById('movement-kpi-refunds');
            const x=arr.filter(m=>m.nature==='REMBOURSEMENT').reduce((s,m)=>s+nombre(m.montant),0);
            if(r)r.innerHTML=`Remboursements<b>${x.toFixed(0)} Fc</b>`;
            if(!arr.length){el.innerHTML='<p style="text-align:center;color:#718096;">Aucun mouvement financier sur cette période.</p>';return;}
            el.innerHTML=arr.map(m=>{const entree=m.type==='ENTREE';const nature=m.nature||'MANUEL';return `<div class="list-item" style="background:#f8fafc;border-left:4px solid ${entree?'#16a34a':'#dc2626'};padding:9px 12px;margin-bottom:6px;border-radius:6px;font-size:.85rem;"><div><b>${entree?'+':'-'}${nombre(m.montant)} Fc</b> · ${m.mode||'ESPECES'} · <span style="font-weight:700;">${nature}</span><br><small>${m.created_at?new Date(m.created_at).toLocaleString('fr-FR'):''} · ${m.assistant||'Système'}</small><br><span>${m.motif||''}</span>${m.ticket_id?`<br><small>Ticket : ${m.ticket_id}</small>`:''}${m.reference_id?` · <small>Réf : ${m.reference_id}</small>`:''}</div></div>`}).join('');
        }
        async function chargerTopsAvances(type){const el=document.getElementById('advanced-tops');if(!el)return;const lines={};financeTicketsCache.forEach(t=>{});try{const {data,error}=await dbCloud.from('ticket_lignes').select('*').eq('statut','VALIDE');if(error)throw error;const now=Date.now(), agg={};(data||[]).forEach(l=>{const id=l.produit_id;if(!agg[id])agg[id]={nom:l.nom,qte:0,ca:0,marge:0};agg[id].qte+=nombre(l.quantite);agg[id].ca+=nombre(l.total);agg[id].marge+=nombre(l.profit)});let arr=Object.values(agg);if(type==='rentabilite')arr.sort((a,b)=>b.marge-a.marge);else if(type==='categories'){const cats={};(data||[]).forEach(l=>{const prod=inventaire.find(p=>String(p.id)===String(l.produit_id));const c=prod?.categorie||'Non classé';if(!cats[c])cats[c]={nom:c,qte:0,ca:0,marge:0};cats[c].qte+=nombre(l.quantite);cats[c].ca+=nombre(l.total);cats[c].marge+=nombre(l.profit)});arr=Object.values(cats).sort((a,b)=>b.ca-a.ca)}else if(type==='dormants')arr=inventaire.filter(p=>p.actif!==false).map(p=>{const a=agg[p.id]||{qte:0,ca:0,marge:0};return{nom:p.nom,qte:a.qte,ca:a.ca,marge:a.marge,stock:nombre(p.stock),immobilise:nombre(p.stock)*nombre(p.pua)}}).filter(x=>x.qte===0||x.stock>10).sort((a,b)=>(b.immobilise-a.immobilise));else arr.sort((a,b)=>b.qte-a.qte);arr=arr.slice(0,10);el.innerHTML=arr.length?`<table class="table"><thead><tr><th>#</th><th>Produit</th><th>Qté</th><th>CA</th><th>Marge</th>${type==='dormants'?'<th>Immobilisé</th>':''}</tr></thead><tbody>${arr.map((x,i)=>`<tr><td>${i+1}</td><td><b>${x.nom}</b></td><td>${x.qte.toFixed(0)}</td><td>${x.ca.toFixed(0)} Fc</td><td>${x.marge.toFixed(0)} Fc</td>${type==='dormants'?`<td>${x.immobilise.toFixed(0)} Fc</td>`:''}</tr>`).join('')}</tbody></table>`:'<p>Aucune donnée.</p>';renderMarginMatrix(agg)}catch(e){el.innerHTML='<p style="color:#b91c1c;">Erreur tops : '+e.message+'</p>'}}
        function renderMarginMatrix(agg){const el=document.getElementById('sales-margin-matrix');if(!el)return;const arr=Object.values(agg);const avgQ=arr.length?arr.reduce((s,x)=>s+x.qte,0)/arr.length:0;const avgM=arr.length?arr.reduce((s,x)=>s+x.marge,0)/arr.length:0;const buckets=[['⭐ Stars',arr.filter(x=>x.qte>=avgQ&&x.marge>=avgM)],['📦 Volume',arr.filter(x=>x.qte>=avgQ&&x.marge<avgM)],['💎 Opportunités',arr.filter(x=>x.qte<avgQ&&x.marge>=avgM)],['🐌 Dormants',arr.filter(x=>x.qte<avgQ&&x.marge<avgM)]];el.innerHTML='<h4>Matrice ventes × marge</h4><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:8px;">'+buckets.map(b=>`<div style="background:#f8fafc;border-radius:10px;padding:10px;"><b>${b[0]}</b><br><small>${b[1].slice(0,5).map(x=>x.nom).join(', ')||'—'}</small></div>`).join('')+'</div>'}
        function renderCreditDashboard(){const el=document.getElementById('credit-dashboard');if(!el)return;const debts={};financeTicketsCache.forEach(t=>{if(nombre(t.montant_credit)>0&&t.client_id)debts[t.client_id]=(debts[t.client_id]||0)+nombre(t.montant_credit)});financePaymentsCache.forEach(p=>{if(p.client_id)debts[p.client_id]=(debts[p.client_id]||0)-nombre(p.montant)});const arr=Object.entries(debts).map(([id,d])=>({client:clients.find(c=>String(c.id)===id)?.nom||('Client #'+id),d:Math.max(0,d)})).filter(x=>x.d>0).sort((a,b)=>b.d-a.d);const total=arr.reduce((s,x)=>s+x.d,0);el.innerHTML=`<b>${arr.length} débiteur(s) — ${total.toFixed(0)} Fc</b><div style="margin-top:8px;">${arr.slice(0,8).map(x=>`<div style="display:flex;justify-content:space-between;padding:6px;border-bottom:1px solid #eee;"><span>${x.client}</span><b>${x.d.toFixed(0)} Fc</b></div>`).join('')||'<p>Aucun crédit en cours.</p>'}</div>`}
        function renderBriefing(){const el=document.getElementById('pharmasys-briefing');if(!el)return;const today=new Date();const last7=financeTicketsCache.filter(t=>(today-new Date(t.date))/86400000<=7);const ca7=last7.reduce((s,t)=>s+nombre(t.montant_total),0);const rupt=inventaire.filter(p=>p.actif!==false&&stockEstCritique(p.stock, p.categorie)).length;const exp=inventaire.filter(p=>p.actif!==false&&p.peremption&&((new Date(p.peremption)-today)/86400000)<=30).length;el.innerHTML=`<div style="font-size:.95rem;line-height:1.8;">CA 7 jours : <b>${ca7.toFixed(0)} Fc</b> · ${last7.length} tickets · 🔴 ${rupt} ruptures · ⏳ ${exp} péremptions <30j.<br><b>Priorité :</b> ${rupt? 'traiter les ruptures imminentes':'activité stock stable'}${exp?' puis sécuriser les produits proches de péremption.':''}</div>`}
        function renderSmartReorder(){const el=document.getElementById('smart-reorder-dashboard');if(!el)return;const since=new Date();since.setDate(since.getDate()-30);const sold={};historiqueVentes.filter(v=>v.statut==='VALIDE'&&new Date(v.date)>=since).forEach(v=>sold[v.produit_id]=(sold[v.produit_id]||0)+nombre(v.quantite));const rec=inventaire.filter(p=>p.actif!==false).map(p=>{const avg=(sold[p.id]||0)/30,lead=5,safety=Math.max(2,avg*2),need=Math.ceil(avg*(lead+7)+safety-nombre(p.stock));return{p,avg,need}}).filter(x=>x.need>0).sort((a,b)=>b.need-a.need).slice(0,10);el.innerHTML=rec.length?'<table class="table"><thead><tr><th>Produit</th><th>Stock</th><th>Conso/j</th><th>Rupture estimée</th><th>Suggestion</th></tr></thead><tbody>'+rec.map(x=>`<tr><td>${x.p.nom}</td><td>${nombre(x.p.stock)}</td><td>${x.avg.toFixed(1)}</td><td>${x.avg>0?(nombre(x.p.stock)/x.avg).toFixed(1)+' j':'—'}</td><td><b>${x.need}</b></td></tr>`).join('')+'</tbody></table>':'<p>Pas de réapprovisionnement urgent selon les 30 derniers jours.</p>'}
        function renderForecast(){const el=document.getElementById('sales-forecast-dashboard');if(!el)return;const days={};financeTicketsCache.forEach(t=>{days[t.date]=(days[t.date]||0)+nombre(t.montant_total)});const vals=Object.values(days);const avg=vals.length?vals.slice(-30).reduce((a,b)=>a+b,0)/Math.min(vals.length,30):0;el.innerHTML=`<h4>📈 Prévision simple</h4><p>CA moyen journalier récent : <b>${avg.toFixed(0)} Fc</b>. Prévision indicative des 7 prochains jours : <b>${(avg*7).toFixed(0)} Fc</b>.</p>`}
        function renderAnomalies(){const c=document.getElementById('cash-anomaly-dashboard'),s=document.getElementById('stock-anomaly-dashboard');if(!c||!s)return;const by={};financeTicketsCache.forEach(t=>{by[t.assistant]=(by[t.assistant]||0)+1});const avg=Object.values(by).length?Object.values(by).reduce((a,b)=>a+b,0)/Object.values(by).length:0;const unusual=Object.entries(by).filter(x=>x[1]>avg*2);const cancels=historiqueVentes.filter(v=>v.statut==='ANNULEE').length;c.innerHTML=`${unusual.length?'<b>⚠️ Activité inhabituelle :</b> '+unusual.map(x=>x[0]+' ('+x[1]+' tickets)').join(', '):'✅ Aucun pic de ventes inhabituel détecté.'}<br>${cancels?'⚠️ '+cancels+' ligne(s) de vente annulée(s) à vérifier.':'✅ Pas d’annulation détectée.'}`;const adj=mouvementsStock.filter(m=>String(m.type).includes('AJUSTEMENT')).reduce((o,m)=>{o[m.produit_id]=(o[m.produit_id]||0)+1;return o},{});const suspects=Object.entries(adj).filter(x=>x[1]>=2).slice(0,8);s.innerHTML='<b>📦 Anomalies stock :</b> '+(suspects.length?suspects.map(x=>(inventaire.find(p=>String(p.id)===x[0])?.nom||x[0])+' — '+x[1]+' ajustements').join('<br>'):'Aucune répétition d’ajustement détectée.')}

        async function validerPanier() {
            if (!utilisateurConnecte) { alert("Veuillez vous connecter."); return; }
            if (!panier || panier.length === 0) { alert("Le panier est vide."); return; }
            const btn = document.getElementById("btn-valider-panier");
            const btnOriginalHTML = btn ? btn.innerHTML : "";
            if (btn) { btn.disabled = true; btn.innerHTML = "<span class='btn-spinner'></span>Validation..."; }

            try {
                const numeroTicket = genererNumeroTicket();
                const maintenant = new Date();
                const offset = maintenant.getTimezoneOffset();
                const dateLocale = new Date(maintenant.getTime() - offset * 60000).toISOString().split("T")[0];
                const heureLocale = maintenant.toLocaleTimeString("fr-FR");
                let montantTotal = 0, beneficeTotal = 0, nbArticles = 0;
                const lignesRpc = [];

                for (const ligne of panier) {
                    const produit = inventaire.find(p => p.id == ligne.id);
                    if (!produit) throw new Error("Produit introuvable : " + ligne.nom);
                    const qte = Number(ligne.quantite);
                    if (!Number.isFinite(qte) || qte <= 0) throw new Error("Quantité invalide pour " + produit.nom);
                    if (Number(produit.stock) < qte) throw new Error("Stock insuffisant pour " + produit.nom);
                    const pua = Number(ligne.pua ?? produit.pua ?? 0);
                    const pvu = Number(ligne.pvu ?? produit.pvu ?? 0);
                    montantTotal += qte * pvu;
                    beneficeTotal += qte * (pvu - pua);
                    nbArticles += qte;
                    lignesRpc.push({ produit_id: Number(produit.id), quantite: qte });
                }

                const paiements = construirePaiementsVente(montantTotal);
                if (!reseauDisponible()) {
                    const venteOffline = { ticket: { id:numeroTicket, date:dateLocale, heure:heureLocale, assistant:utilisateurConnecte.nom, assistant_id:utilisateurConnecte.id, nb_articles:nbArticles, montant_total:montantTotal, benefice_total:beneficeTotal, statut:"VALIDE", mode_paiement: paiements.length > 1 ? "MIXTE" : (paiements[0]?.mode || "ESPECES"), paiements:paiements }, lignes:[], mouvements:[], historique:[], stocks:[] };
                    for (const ligne of panier) {
                        const produit = inventaire.find(p => p.id == ligne.id);
                        const avant = Number(produit.stock);
                        const apres = Number((avant - Number(ligne.quantite)).toFixed(2));
                        const total = Number((Number(ligne.quantite) * Number(ligne.pvu)).toFixed(2));
                        const profit = Number((Number(ligne.quantite) * (Number(ligne.pvu) - Number(ligne.pua))).toFixed(2));
                        venteOffline.lignes.push({ ticket_id:numeroTicket, produit_id:produit.id, nom:produit.nom, quantite:ligne.quantite, pua:ligne.pua, pvu:ligne.pvu, total:total, profit:profit, statut:"VALIDE" });
                        venteOffline.historique.push({ id:numeroTicket+"-"+produit.id, date:dateLocale, heure:heureLocale, assistant:utilisateurConnecte.nom, assistant_id:utilisateurConnecte.id, produit_id:produit.id, nom:produit.nom, quantite:ligne.quantite, pua:ligne.pua, pvu:ligne.pvu, total:total, profit:profit, statut:"VALIDE" });
                        venteOffline.mouvements.push({ date:maintenant.toLocaleDateString("fr-FR")+" "+maintenant.toLocaleTimeString("fr-FR"), created_at:maintenant.toISOString(), assistant:utilisateurConnecte.nom, produit_id:Number(produit.id), produit:produit.nom, type:"VENTE", quantite:nombre(ligne.quantite), stock_avant:avant, stock_apres:apres, observation:"Vente "+numeroTicket, ticket:numeroTicket });
                        venteOffline.stocks.push({ id:produit.id, apres:apres });
                        produit.stock = apres;
                    }
                    await enqueueOfflineOperation("VENTE", {ticket: venteOffline.ticket, lignes: venteOffline.lignes});
                    panier = [];
                    renderPanier();
                    setConnectionStatus("offline");
                    alert("Vente enregistrée hors-ligne. Elle sera synchronisée à la reconnexion. Ticket : " + numeroTicket);
                    return;
                }

                setConnectionStatus("syncing");
                const { data, error } = await dbCloud.rpc("valider_vente", {
                    p_ticket_id: numeroTicket,
                    p_date: dateLocale,
                    p_heure: heureLocale,
                    p_assistant: utilisateurConnecte.nom,
                    p_assistant_id: utilisateurConnecte.id,
                    p_lignes: lignesRpc,
                    p_paiements: paiements
                });

                if (error) {
                    const status = Number(error.status || error.code || 0);
                    if (status === 401 || /invalid api key|api key/i.test(error.message || "")) {
                        throw new Error("Authentification Supabase refusée (401) : vérifiez que la clé anon/publishable correspond bien à l'URL du même projet Supabase.");
                    }
                    if (/function .*valider_vente|does not exist|schema cache/i.test(error.message || "")) {
                        throw new Error("La fonction Supabase valider_vente V13 n'est pas encore installée. Exécutez la migration V13 dans Supabase.");
                    }
                    throw new Error(error.message || "Validation de la vente impossible");
                }
                if (!data || data.success !== true) throw new Error("Supabase n'a pas confirmé la vente.");

                panier = [];
                renderPanier();
                const qty = document.getElementById("sale-qty"); if (qty) qty.value = 1;
                const selected = document.getElementById("ast-selected-area"); if (selected) selected.style.display = "none";
                selectedProductIdAst = null;
                await chargerDonnees();
                setConnectionStatus("online");
                alert("Vente enregistrée avec succès. Ticket : " + numeroTicket);
            } catch (err) {
                console.error("Erreur validerPanier :", err);
                alert("Vente non enregistrée : " + (err.message || err));
                setConnectionStatus(reseauDisponible() ? "online" : "offline");
            } finally {
                if (btn) { btn.disabled = false; btn.innerHTML = btnOriginalHTML; }
            }
        }

        function genererNumeroTicket() {
            const maintenant = new Date();
            const annee = maintenant.getFullYear();
            const mois = String(maintenant.getMonth() + 1).padStart(2, "0");
            const jour = String(maintenant.getDate()).padStart(2, "0");
            const compteur = Date.now().toString().slice(-4);
            return "TK-" + annee + mois + jour + "-" + compteur;
        }

        function renderPanier() {
            const liste = document.getElementById("cart-list");
            const total = document.getElementById("cart-total");
            if (!liste || !total) return;
            liste.innerHTML = "";
            if (panier.length === 0) {
                liste.innerHTML = "<p style='text-align:center;color:#718096;'>Le panier est vide.</p>";
                total.innerText = "0 Fc";
                const resume = document.getElementById("cart-resume");
                if (resume) resume.innerHTML = "<div style='text-align:center;color:#718096;'>Aucun produit dans le panier.</div>";
                return;
            }
            let totalGeneral = 0;
            panier.forEach((item, index) => {
                const sousTotal = item.quantite * item.pvu;
                totalGeneral += sousTotal;
                const stockActuel = nombre(inventaire.find(p => p.id == item.id) ? inventaire.find(p => p.id == item.id).stock : 0);
                liste.innerHTML += `<div class="list-item" style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #e2e8f0;"><div><b>${item.nom}</b><br><span style="color:#2563eb;">Prix : ${nombre(item.pvu)} Fc</span><div style="display:flex;align-items:center;gap:8px;margin:8px 0;"><button onclick='diminuerQuantitePanier(${index})' style="width:auto;padding:4px 8px;">-</button><b style="min-width:30px;text-align:center;">${item.quantite}</b><button onclick='augmenterQuantitePanier(${index})' style="width:auto;padding:4px 8px;" ${item.quantite >= stockActuel ? "disabled" : ""}>+</button></div><div style="font-size:13px;color:#16a34a;font-weight:bold;">Sous-total : ${nombre(item.pvu * item.quantite)} Fc</div><div style="font-size:12px;">Stock : ${stockActuel} | Restera : ${stockActuel - item.quantite}</div></div><div style="text-align:right;"><div style="font-weight:bold;">${sousTotal.toFixed(2).replace(/\.00$/,"")} Fc</div><button style="margin-top:5px;background:#dc2626;padding:4px 8px;width:auto;" onclick='supprimerDuPanier(${index})'>X</button></div></div>`;
            });
            const resume = document.getElementById("cart-resume");
            let nbUnites = 0, benefice = 0;
            panier.forEach(item => { nbUnites += nombre(item.quantite); benefice += (nombre(item.pvu) - nombre(item.pua)) * nombre(item.quantite); });
            if (resume) {
                if (resume) resume.innerHTML = `<div style="display:flex;justify-content:space-between;"><span>Produits differents</span><b>${panier.length}</b></div><div style="display:flex;justify-content:space-between;margin-top:4px;"><span>Quantite totale</span><b>${nbUnites}</b></div><div style="display:flex;justify-content:space-between;margin-top:4px;"><span>Montant total</span><b>${totalGeneral.toFixed(2).replace(/\.00$/,"")} Fc</b></div><div style="display:flex;justify-content:space-between;margin-top:4px;color:#16a34a;"><span>Benefice estime</span><b>${benefice.toFixed(2).replace(/\.00$/,"")} Fc</b></div>`;
            }
            total.innerText = totalGeneral.toFixed(2).replace(/\.00$/,"") + " Fc";
        }

        function supprimerDuPanier(index) { panier.splice(index,1); renderPanier(); }
        function augmenterQuantitePanier(index) {
            const ligne = panier[index]; if (!ligne) return;
            const produit = inventaire.find(p => p.id == ligne.id); if (!produit) return;
            if (ligne.quantite + 1 > nombre(produit.stock)) { alert("Stock insuffisant."); return; }
            ligne.quantite++; renderPanier();
        }
        function diminuerQuantitePanier(index) {
            const ligne = panier[index]; if (!ligne) return;
            ligne.quantite--; if (ligne.quantite <= 0) panier.splice(index,1);
            renderPanier();
        }
        function viderPanier() {
            if (panier.length === 0) return;
            if (!confirm("Vider le panier ?")) return;
            panier = []; renderPanier();
        }

        async function annulerVente(idVente) {
            const evt = (typeof event !== "undefined") ? event : null;
            const btn = evt && evt.currentTarget ? evt.currentTarget : null;
            if (btn && btn.disabled) return;
            if (btn) { btn.disabled = true; btn.dataset.originalText = btn.innerText; btn.innerText = "Annulation..."; }
            try {
                const vente = historiqueVentes.find(v => String(v.id) === String(idVente));
                if (!vente) throw new Error("Vente introuvable");
                if (vente.statut === "ANNULEE") { alert("Vente deja annulee."); return; }
                if (!confirm("Annuler la vente de " + (vente.nom || "") + " ?")) return;
                const payload={p_historique_id:String(vente.id)};
                if(!reseauDisponible()){await enqueueOfflineOperation("ANNULER_LIGNE_HISTORIQUE",payload);alert("Annulation mise en attente hors-ligne. Le stock sera restauré lors de la synchronisation.");return;}
                const { data, error } = await dbCloud.rpc("annuler_ligne_ticket", payload);
                if (error) throw error;
                if (!data || data.success !== true) throw new Error(data && data.message ? data.message : "Annulation non confirmée");
                await chargerDonnees();
                alert("Article annulé : stock restitué et remboursement enregistré.");
            } catch (error) {
                console.error(error);
                alert("Erreur lors de l'annulation : " + (error.message || error));
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = btn.dataset.originalText || "Annuler"; }
            }
        }

        async function annulerArticleTicket(ligneId) {
            const evt = (typeof event !== "undefined") ? event : null;
            const btn = evt && evt.currentTarget ? evt.currentTarget : null;
            if (btn && btn.disabled) return;
            if (btn) { btn.disabled = true; btn.dataset.originalText = btn.innerText; btn.innerText = "..."; }
            try {
                if (!confirm("Annuler cet article et restituer exactement sa quantité en stock ?")) return;
                const payload={p_ligne_id:Number(ligneId)};
                if(!reseauDisponible()){await enqueueOfflineOperation("ANNULER_ARTICLE",payload);alert("Annulation de l'article mise en attente hors-ligne.");return;}
                const { data, error } = await dbCloud.rpc("annuler_article_ticket", payload);
                if (error) throw error;
                if (!data || data.success !== true) throw new Error(data && data.message ? data.message : "Annulation non confirmée");
                await chargerDonnees();
                if (ticketActuel && ticketActuel.id) await afficherTicketDetail(ticketActuel.id);
                alert("Article annulé : stock restitué et remboursement enregistré.");
            } catch (error) {
                console.error(error);
                alert("Erreur lors de l'annulation de l'article : " + (error.message || error));
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = btn.dataset.originalText || "Annuler"; }
            }
        }

        async function annulerTicket() {
            if (!ticketActuel || !ticketActuel.id) return;
            const btn = document.querySelector("#ticket-modal button[onclick=\"annulerTicket()\"]");
            if (btn && btn.disabled) return;
            if (ticketActuel.statut === "ANNULEE") { alert("Ticket deja annule."); return; }
            if (!confirm("Annuler entierement le ticket " + ticketActuel.id + " ? Le stock de toutes les lignes sera restitue.")) return;
            if (btn) { btn.disabled = true; btn.dataset.originalText = btn.innerText; btn.innerText = "..."; }
            try {
                const payload={p_ticket_id:String(ticketActuel.id)};
                if(!reseauDisponible()){await enqueueOfflineOperation("ANNULER_TICKET",payload);alert("Annulation du ticket mise en attente hors-ligne.");return;}
                const { data, error } = await dbCloud.rpc("annuler_ticket", payload);
                if (error) throw error;
                if (!data || data.success !== true) throw new Error(data && data.message ? data.message : "Annulation non confirmée");
                await chargerDonnees();
                document.getElementById("ticket-modal").style.display = "none";
                ticketActuel = null;
                alert("Ticket annulé : stock restitué et remboursements enregistrés selon les paiements d’origine.");
            } catch (error) {
                console.error(error);
                alert("Erreur lors de l'annulation du ticket : " + (error.message || error));
            } finally {
                if (btn) { btn.disabled = false; btn.innerText = btn.dataset.originalText || "C"; }
            }
        }

        async function imprimerTicket(ticketId) {
            try {
                const { data: ticket, error } = await dbCloud.from("tickets").select("*").eq("id", ticketId).single();
                if (error || !ticket) { alert("Ticket introuvable."); return; }
                const { data: lignes, error: errL } = await dbCloud.from("ticket_lignes").select("*").eq("ticket_id", ticketId);
                if (errL) { alert("Lignes introuvables."); return; }
                const infos = await obtenirInfosPharmacie();
                let html = "<html><head><title>Ticket " + ticketId + "</title><style>body{font-family:monospace;font-size:12px;width:280px;margin:0 auto;padding:10px;}h2{text-align:center;margin:5px 0;}hr{border:none;border-top:1px dashed #999;margin:8px 0;}table{width:100%;border-collapse:collapse;}td{padding:2px 0;}.right{text-align:right;}.center{text-align:center;}</style></head><body>";
                if (infos.logo_url) html += `<div class="center"><img src="${infos.logo_url}" style="width:80px;height:80px;object-fit:contain;"></div>`;
                html += "<h2>" + (infos.nom || "Pharmacie") + "</h2>";
                if (infos.adresse) html += `<div class="center">${infos.adresse}</div>`;
                if (infos.telephone) html += `<div class="center">Tel: ${infos.telephone}</div>`;
                html += "<hr><div>Ticket: " + ticketId + "</div><div>Date: " + ticket.date + " " + (ticket.heure||"") + "</div><div>Vendeur: " + ticket.assistant + "</div><hr><table>";
                (lignes||[]).forEach(l => {
                    html += `<tr><td>${l.quantite}x ${l.nom}</td><td class="right">${nombre(l.total)} Fc</td></tr>`;
                });
                html += `</table><hr><div style="font-size:16px;font-weight:bold;">TOTAL: ${nombre(ticket.montant_total)} Fc</div><hr>`;
                html += "<div class='center'>Merci de votre confiance</div>";
                if (infos.slogan) html += `<div class="center" style="font-style:italic;">${infos.slogan}</div>`;
                html += "</body></html>";
                const w = window.open("", "_blank");
                w.document.write(html); w.document.close(); w.print();
            } catch (e) { console.error(e); alert("Erreur impression : " + e.message); }
        }

        async function exporterTicketPDF() {
            if (!ticketActuel) return;
            alert("Export PDF non disponible dans cette version.");
        }

        async function partagerTicket() {
            if (!ticketActuel) return;
            const texte = "Ticket " + ticketActuel.id + " - Total: " + nombre(ticketActuel.montant_total) + " Fc";
            if (navigator.share) { try { await navigator.share({ title:"Ticket PharmaSys", text:texte }); } catch(e){} }
            else { navigator.clipboard.writeText(texte); alert("Ticket copie."); }
        }

        function fermerTicket() {
            document.getElementById("ticket-modal").style.display = "none";
            ticketActuel = null;
        }

        function renderBilanVentes() {
            const container = document.getElementById("bilan-ventes");
            if (!container) return;
            const ventesValides = historiqueVentes.filter(v => v.statut === "VALIDE");
            const nbVentes = ventesValides.length;
            const totalMontant = ventesValides.reduce((s,v) => s + nombre(v.total), 0);
            const totalBenefice = ventesValides.reduce((s,v) => s + nombre(v.profit), 0);
            container.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;"><div style="text-align:center;"><div style="font-size:11px;color:#718096;">Ventes</div><div style="font-size:20px;font-weight:bold;color:var(--primary-dark);">${nbVentes}</div></div><div style="text-align:center;"><div style="font-size:11px;color:#718096;">Montant</div><div style="font-size:20px;font-weight:bold;color:#2563eb;">${totalMontant.toFixed(0)} Fc</div></div><div style="text-align:center;"><div style="font-size:11px;color:#718096;">Benefice</div><div style="font-size:20px;font-weight:bold;color:#16a34a;">${totalBenefice.toFixed(0)} Fc</div></div></div>`;
        }

        function renderAdminScreen() {
            const log = document.getElementById("admin-sales-log");
            if (!log) return;
            log.innerHTML = "";
            const ventesTriees = [...historiqueVentes].sort((a,b) => (b.date + (b.heure||"")).localeCompare(a.date + (a.heure||"")));
            if (ventesTriees.length === 0) { log.innerHTML = "<p style='text-align:center;color:#718096;'>Aucune vente.</p>"; return; }
            ventesTriees.forEach(v => {
                const estAnnulee = v.statut === "ANNULEE";
                const bg = estAnnulee ? "#fef2f2" : "#f0fff4";
                const border = estAnnulee ? "var(--danger)" : "var(--success)";
                log.innerHTML += `<div class="list-item" style="background:${bg};border-left:4px solid ${border};padding:8px 12px;margin-bottom:5px;border-radius:4px;font-size:0.85rem;"><div><b>${v.nom||""}</b> - ${nombre(v.quantite)} u a ${nombre(v.pvu)} Fc<br><small>${v.date} ${v.heure||""} | ${v.assistant}</small></div><div style="text-align:right;"><b>${nombre(v.total)} Fc</b>${estAnnulee ? " <span class='badge alert'>ANNULEE</span>" : ""}<button onclick='annulerVente(${JSON.stringify(v.id)})' style="width:auto;padding:4px 8px;font-size:0.75rem;background:var(--danger);margin-left:5px;" ${estAnnulee ? "disabled" : ""}>Annuler</button></div></div>`;
            });
        }

        function renderTop10Ventes() {
            const container = document.getElementById("admin-top-10-liste");
            if (!container) return;
            const ventesValides = historiqueVentesTop10.filter(v => v.statut === "VALIDE");
            const parProduit = {};
            ventesValides.forEach(v => {
                if (!parProduit[v.produit_id]) parProduit[v.produit_id] = { nom:v.nom, qte:0, montant:0, profit:0 };
                parProduit[v.produit_id].qte += nombre(v.quantite);
                parProduit[v.produit_id].montant += nombre(v.total);
                parProduit[v.produit_id].profit += nombre(v.profit);
            });
            const top10 = Object.values(parProduit).sort((a,b) => b.qte - a.qte).slice(0, 10);
            if (top10.length === 0) { container.innerHTML = "<p style='text-align:center;color:#718096;'>Aucune vente sur la periode.</p>"; return; }
            let html = "<table class='table'><thead><tr><th>#</th><th>Medicament</th><th>Qte vendue</th><th>Montant</th><th>Benefice</th></tr></thead><tbody>";
            top10.forEach((p, i) => {
                html += `<tr><td>${i+1}</td><td><b>${p.nom}</b></td><td>${p.qte}</td><td>${p.montant.toFixed(0)} Fc</td><td style="color:#16a34a;">${p.profit.toFixed(0)} Fc</td></tr>`;
            });
            html += "</tbody></table>";
            container.innerHTML = html;
        }

        function renderMouvements() {
            const container = document.getElementById("shared-liste-mouvements");
            if (!container) return;
            const note = document.getElementById('movement-visibility-note');
            if (note) note.innerHTML = estAdministrateur() ? "👑 <b>Administrateur :</b> vous voyez tous les flux de la pharmacie." : "👤 <b>Vue personnelle :</b> vous voyez vos flux et les modifications effectuées par l’administrateur.";
            container.innerHTML = "";
            const filtre = document.getElementById("filter-mouvements");
            const filtreTexte = filtre ? filtre.value.toLowerCase().trim() : "";
            let mouvementsAffiches = mouvementsDansPeriode(mouvementsStock).sort((a,b) => (dateLocaleMouvement(b)?.getTime()||0) - (dateLocaleMouvement(a)?.getTime()||0));
            if (filtreTexte) {
                mouvementsAffiches = mouvementsAffiches.filter(m =>
                    (m.produit||"").toLowerCase().includes(filtreTexte) ||
                    (m.type||"").toLowerCase().includes(filtreTexte) ||
                    (m.assistant||"").toLowerCase().includes(filtreTexte)
                );
            }
            if (mouvementsAffiches.length === 0) { container.innerHTML = "<p style='text-align:center;color:#718096;'>Aucun mouvement.</p>"; return; }
            mouvementsAffiches.forEach(m => {
                let couleur, icone;
                switch (m.type) {
                    case "VENTE": couleur = "#dc2626"; icone = "Vente"; break;
                    case "REAPPRO": couleur = "#16a34a"; icone = "Reappro"; break;
                    case "ANNULATION": couleur = "#f59e0b"; icone = "Annul."; break;
                    case "AJUSTEMENT_INVENTAIRE": couleur = "#2563eb"; icone = "Ajust."; break;
                    default: couleur = "#64748b"; icone = m.type;
                }
                container.innerHTML += `<div class="list-item" style="background:#f8fafc;border-left:4px solid ${couleur};padding:8px 12px;margin-bottom:5px;border-radius:4px;font-size:0.85rem;"><div><b>${m.produit||""}</b><br><small>${m.date||""} | ${m.assistant||""}</small><br><span style="color:${couleur};font-weight:bold;">${icone}</span> ${nombre(m.quantite)} u (${nombre(m.stock_avant)} -> ${nombre(m.stock_apres)})</div></div>`;
            });
            const k=document.getElementById('movement-kpi-stock'); if(k)k.innerHTML=`Stock<b>${mouvementsAffiches.length} flux</b>`;
            renderMouvementsCaisse();
        }


        function renderArchives() {
            const container = document.getElementById("listeArchives");
            if (!container) return;
            container.innerHTML = "";
            const filtre = document.getElementById("filter-archives");
            const filtreTexte = filtre ? filtre.value.toLowerCase().trim() : "";
            const archives = inventaire.filter(p => p.actif === false);
            const archivesFiltrees = filtreTexte ? archives.filter(p => p.nom.toLowerCase().includes(filtreTexte)) : archives;
            if (archivesFiltrees.length === 0) { container.innerHTML = "<p style='text-align:center;color:#718096;'>Corbeille vide.</p>"; return; }
            archivesFiltrees.forEach(p => {
                container.innerHTML += `<div class="list-item" style="background:#f8fafc;padding:8px 12px;margin-bottom:5px;border-radius:4px;font-size:0.85rem;"><div><b>${p.nom}</b><br><small>Stock: ${nombre(p.stock)} | P.V.U: ${nombre(p.pvu)} Fc</small></div><div><button onclick='restaurerProduit(${p.id})' style="width:auto;padding:4px 10px;font-size:0.75rem;background:var(--success);">Restaurer</button></div></div>`;
            });
        }

        async function archiverProduit() {
            if (!selectedProductIdAdm) return;
            if (!confirm("Archiver cet article ? Il sera deplace vers la corbeille.")) return;
            await dbCloud.from("inventaire").update({ actif: false }).eq("id", selectedProductIdAdm);
            document.getElementById("adm-focus-card").style.display = "none";
            selectedProductIdAdm = null;
            await chargerDonnees();
            alert("Article archive.");
        }

        async function restaurerProduit(id) {
            await dbCloud.from("inventaire").update({ actif: true }).eq("id", id);
            await chargerDonnees();
            alert("Article restaure.");
        }

        async function addNewProduct() {
            const nom = document.getElementById("new-nom").value.trim();
            const pua = nombre(document.getElementById("new-pua").value);
            const pvu = nombre(document.getElementById("new-pvu").value);
            const stock = nombre(document.getElementById("new-stock").value);
            const categorie = document.getElementById("new-categorie").value.trim() || "Non classé";
            if (!nom) { alert("Veuillez saisir un nom."); return; }
            const { error } = await dbCloud.from("inventaire").insert([{ nom:nom, pua:pua, pvu:pvu, stock:stock, categorie:categorie, actif:true, tenant_id:TENANT_ID }]);
            if (error) { alert("Erreur : " + error.message); return; }
            document.getElementById("new-nom").value = "";
            document.getElementById("new-pua").value = "0";
            document.getElementById("new-pvu").value = "0";
            document.getElementById("new-stock").value = "0"; document.getElementById("new-categorie").value = "";
            await chargerDonnees();
            alert("Medicament ajoute.");
        }

        async function modifierProduit() {
            if (!selectedProductIdAdm) return;
            const nom = document.getElementById("focus-nom").innerText.trim();
            const pua = nombre(document.getElementById("focus-input-pua").value);
            const pvu = nombre(document.getElementById("focus-input-pvu").value);
            const peremption = document.getElementById("focus-input-peremption").value || null;
            const categorie = document.getElementById("focus-input-categorie")?.value.trim() || "Non classé";
            const { error } = await dbCloud.from("inventaire").update({ nom:nom, pua:pua, pvu:pvu, peremption:peremption, categorie:categorie }).eq("id", selectedProductIdAdm);
            if (error) { alert("Erreur : " + error.message); return; }
            await chargerDonnees();
            alert("Caracteristiques enregistrees.");
        }

        async function applyReapp() {
            if (!selectedProductIdAdm) return;
            const qte = nombre(document.getElementById("focus-input-reapp").value);
            if (qte <= 0) { alert("Quantite invalide."); return; }
            const produit = inventaire.find(p => p.id == selectedProductIdAdm);
            if (!produit) return;
            const payload={p_produit_id:produit.id,p_quantite:qte,p_observation:"Reapprovisionnement",p_assistant:utilisateurConnecte?utilisateurConnecte.nom:"Système"};
            if(!reseauDisponible()){produit.stock=nombre(produit.stock)+qte;await enqueueOfflineOperation("REAPPRO",payload);document.getElementById("focus-input-reapp").value="";showAdminFocusCard(produit);alert("Réapprovisionnement enregistré hors-ligne. Il sera synchronisé automatiquement.");return;}
            const { data, error } = await dbCloud.rpc("reapprovisionner_stock", payload);
            if (error) { alert("Erreur réapprovisionnement : " + error.message); return; }
            if (!data || data.success !== true) { alert("Réapprovisionnement non confirmé."); return; }
            document.getElementById("focus-input-reapp").value = "";
            await chargerDonnees();
            showAdminFocusCard(inventaire.find(p => p.id == selectedProductIdAdm));
            alert("Stock approvisionne de " + qte + " unites.");
        }

        function switchScreen(screen) {
            const screenIds = ["screen-assistant", "screen-mouvements", "screen-reseau", "screen-admin"];
            screenIds.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.style.display = "none";
            });
            document.querySelectorAll(".nav-item").forEach(b => b.classList.remove("active"));

            if (screen === "assistant") {
                const el = document.getElementById("screen-assistant");
                const nav = document.getElementById("nav-assistant");
                if (el) el.style.display = "block";
                if (nav) nav.classList.add("active");
            } else if (screen === "mouvements") {
                const el = document.getElementById("screen-mouvements");
                const nav = document.getElementById("nav-mouvements");
                if (el) el.style.display = "block";
                if (nav) nav.classList.add("active");
                if (typeof renderMouvements === "function") renderMouvements();
                if (typeof chargerMouvementsCaisse === "function") chargerMouvementsCaisse();
            } else if (screen === "reseau") {
                const el = document.getElementById("screen-reseau");
                const nav = document.getElementById("nav-reseau");
                if (el) el.style.display = "block";
                if (nav) nav.classList.add("active");
                actualiserDiagnosticReseau();
            } else if (screen === "admin") {
                if (!utilisateurConnecte || !rolePeutGerer()) return;
                const el = document.getElementById("screen-admin");
                const nav = document.getElementById("tab-admin-nav");
                if (el) el.style.display = "block";
                if (nav) nav.classList.add("active");
                if (typeof closeAdminSubSection === "function") closeAdminSubSection();
                if (typeof renderAdminScreen === "function") renderAdminScreen();
                if (typeof renderTop10Ventes === "function") renderTop10Ventes();
            }
        }

        async function chargerTickets() {
            if (!dbCloud) return;
            const { data: tickets, error } = await dbCloud.from("tickets").select("*").order("date", { ascending: false }).order("heure", { ascending: false });
            const container = document.getElementById("admin-sales-log");
            if (!container) return;
            if (error) {
                console.error("Erreur tickets :", error);
                container.innerHTML = `<p style="text-align:center;color:#dc2626;">Impossible de charger les tickets : ${error.message}</p>`;
                return;
            }
            container.innerHTML = "";
            if (!tickets || tickets.length === 0) { container.innerHTML = "<p style=\"text-align:center;color:#718096;\">Aucun ticket.</p>"; return; }
            tickets.forEach(t => {
                container.innerHTML += `<div class="list-item" style="background:#f0fff4;border-left:4px solid var(--success);padding:8px 12px;margin-bottom:5px;border-radius:4px;font-size:0.85rem;cursor:pointer;" onclick="afficherTicketDetail('${String(t.id).replace(/'/g, "&#39;")}')"><div><b>Ticket ${t.id}</b><br><small>${t.date} ${(t.heure||"")} | ${t.assistant} | ${(t.nb_articles||0)} articles</small></div><div style="text-align:right;"><b>${nombre(t.montant_total)} Fc</b></div></div>`;
            });
        }

        async function afficherTicketDetail(ticketId) {
            try {
                const { data: ticket, error } = await dbCloud.from("tickets").select("*").eq("id", ticketId).single();
                if (error || !ticket) return;
                const { data: lignes, error: errL } = await dbCloud.from("ticket_lignes").select("*").eq("ticket_id", ticketId);
                if (errL) return;
                ticketActuel = ticket;
                const infos = await obtenirInfosPharmacie();
                let html = "<div style=\"text-align:center;margin-bottom:15px;\">";
                if (infos.logo_url) html += "<img src=\"" + infos.logo_url + "\" style=\"width:80px;height:80px;object-fit:contain;margin-bottom:5px;\">";
                html += "<h2 style=\"margin:0;color:var(--primary-dark);\">" + (infos.nom||"Pharmacie") + "</h2>";
                if (infos.adresse) html += "<div style=\"font-size:12px;color:#666;\">" + infos.adresse + "</div>";
                if (infos.telephone) html += "<div style=\"font-size:12px;color:#666;\">Tel: " + infos.telephone + "</div>";
                html += "</div><hr style=\"border:none;border-top:1px dashed #ccc;\">";
                html += "<div style=\"font-size:13px;margin-bottom:10px;\"><div>Ticket: <b>" + ticket.id + "</b></div><div>Date: " + ticket.date + " " + (ticket.heure||"") + "</div><div>Vendeur: " + ticket.assistant + "</div></div>";
                html += "<hr style=\"border:none;border-top:1px dashed #ccc;\"><table style=\"width:100%;font-size:13px;\"><thead><tr><th style=\"text-align:left;padding:4px 0;\">Produit</th><th style=\"text-align:center;\">Qte</th><th style=\"text-align:right;\">Prix</th><th style=\"text-align:right;\">Total</th><th style=\"text-align:right;\">Action</th></tr></thead><tbody>";
                (lignes||[]).forEach(l => {
                    const estAnnulee = l.statut === "ANNULEE";
                    html += "<tr><td style=\"padding:4px 0;\">" + l.nom + (estAnnulee ? " <span style=\"color:#dc2626;font-size:11px;\">ANNULEE</span>" : "") + "</td><td style=\"text-align:center;\">" + l.quantite + "</td><td style=\"text-align:right;\">" + nombre(l.pvu) + " Fc</td><td style=\"text-align:right;\">" + nombre(l.total) + " Fc</td><td style=\"text-align:right;\"><button " + (estAnnulee ? "disabled" : "") + " onclick=\"annulerArticleTicket(" + l.id + ")\" style=\"width:auto;padding:4px 7px;font-size:11px;background:#dc2626;\">Annuler</button></td></tr>";
                });
                html += "</tbody></table><hr style=\"border:none;border-top:1px dashed #ccc;\">";
                html += "<div style=\"display:flex;justify-content:space-between;font-size:18px;font-weight:bold;margin-top:10px;\"><span>TOTAL</span><span>" + nombre(ticket.montant_total) + " Fc</span></div>";
                html += "<div style=\"text-align:center;margin-top:15px;font-size:12px;color:#666;\">Merci de votre confiance</div>";
                document.getElementById("ticket-contenu").innerHTML = html;
                document.getElementById("ticket-modal").style.display = "block";
            } catch (e) { console.error(e); }
        }

        async function chargerAnalyseVentes(periode) {
            const setLoading = (id, text) => { const el = document.getElementById(id); if (el) el.innerHTML = `<p style="text-align:center;color:#718096;">${text}</p>`; };
            try {
                if (!dbCloud) throw new Error("Connexion Supabase indisponible.");
                let query = dbCloud.from("tickets").select("*").eq("statut", "VALIDE");
                const maintenant = new Date();
                if (periode === "custom") {
                    const p=lirePeriodeFinance();
                    if(!p.debut||!p.fin) throw new Error('Sélectionnez une date de début et une date de fin.');
                    query=query.gte('date',p.debut).lte('date',p.fin);
                } else if (periode === "semaine" || periode === "mois") {
                    const jours = periode === "semaine" ? 7 : 30;
                    const debut = new Date(maintenant);
                    debut.setDate(debut.getDate() - jours);
                    const offset = debut.getTimezoneOffset();
                    const dateDebutStr = new Date(debut.getTime() - offset * 60000).toISOString().split("T")[0];
                    query = query.gte("date", dateDebutStr);
                }
                const { data: tickets, error } = await query.order("date", { ascending: true });
                if (error) throw error;
                const ventesValides = tickets || [];
                const nbTickets = ventesValides.length;
                const totalMontant = ventesValides.reduce((s,t) => s + nombre(t.montant_total), 0);
                const totalBenefice = ventesValides.reduce((s,t) => s + nombre(t.benefice_total), 0);
                const nbArticles = ventesValides.reduce((s,t) => s + nombre(t.nb_articles), 0);
                const titre = periode === "semaine" ? "des 7 derniers jours" : periode === "mois" ? "des 30 derniers jours" : periode === "custom" ? `du ${document.getElementById('finance-date-debut')?.value||''} au ${document.getElementById('finance-date-fin')?.value||''}` : "de toutes les ventes";
                const resume = document.getElementById("ticket-summary");
                if (resume) resume.innerHTML = `<h3 style="margin:0 0 10px;color:var(--primary-dark);">Analyse ${titre}</h3><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;"><div style="text-align:center;"><div style="font-size:11px;color:#666;">Tickets</div><div style="font-size:20px;font-weight:bold;">${nbTickets}</div></div><div style="text-align:center;"><div style="font-size:11px;color:#666;">Articles</div><div style="font-size:20px;font-weight:bold;">${nbArticles}</div></div><div style="text-align:center;"><div style="font-size:11px;color:#666;">Montant</div><div style="font-size:20px;font-weight:bold;color:#2563eb;">${totalMontant.toFixed(0)} Fc</div></div><div style="text-align:center;"><div style="font-size:11px;color:#666;">Bénéfice</div><div style="font-size:20px;font-weight:bold;color:#16a34a;">${totalBenefice.toFixed(0)} Fc</div></div></div>`;
                if (periode === "tout") {
                    await chargerTopProduits(null, null);
                    await chargerPerformanceAssistants(null, null);
                } else if (periode === "custom") {
                    const p=lirePeriodeFinance();
                    await chargerTopProduits(p.debut,p.fin);
                    await chargerPerformanceAssistants(p.debut,p.fin);
                } else {
                    const jours = periode === "semaine" ? 7 : 30;
                    const debut = new Date(maintenant); debut.setDate(debut.getDate() - jours);
                    const offset = debut.getTimezoneOffset();
                    const dateDebutStr = new Date(debut.getTime() - offset * 60000).toISOString().split("T")[0];
                    const dateFinStr = new Date(maintenant.getTime() - offset * 60000).toISOString().split("T")[0];
                    await chargerTopProduits(dateDebutStr, dateFinStr);
                    await chargerPerformanceAssistants(dateDebutStr, dateFinStr);
                }
                await chargerGraphiqueVentes(ventesValides);
                await chargerSynthesePeriode(ventesValides, periode);
            } catch (e) {
                console.error("Erreur analyse ventes :", e);
                setLoading("ticket-summary", "Impossible de charger l'analyse : " + (e.message || e));
                setLoading("top-products-summary", "Données indisponibles");
                setLoading("assistant-performance-summary", "Données indisponibles");
                setLoading("sales-period-summary", "Données indisponibles");
                setLoading("sales-chart", "Données indisponibles");
            }
        }

        async function chargerTopProduits(dateDebut, dateFin) {
            let q = dbCloud.from("ticket_lignes").select("*").eq("statut", "VALIDE");
            if (dateDebut) q = q.gte("created_at", dateDebut + "T00:00:00");
            if (dateFin) q = q.lte("created_at", dateFin + "T23:59:59");
            const { data: lignes, error } = await q;
            if (error) { console.error(error); const c=document.getElementById("top-products-summary"); if(c)c.innerHTML=`<p style="color:#dc2626;text-align:center;">Impossible de charger le top produits : ${error.message}</p>`; return; }
            const parProduit = {};
            (lignes||[]).forEach(l => {
                if (!parProduit[l.produit_id]) parProduit[l.produit_id] = { nom:l.nom, qte:0, montant:0 };
                parProduit[l.produit_id].qte += nombre(l.quantite);
                parProduit[l.produit_id].montant += nombre(l.total);
            });
            const top = Object.values(parProduit).sort((a,b) => b.qte - a.qte).slice(0, 10);
            const container = document.getElementById("top-products-summary");
            if (!container) return;
            if (top.length === 0) { container.innerHTML = "<p style=\"color:#718096;text-align:center;\">Aucune vente.</p>"; return; }
            let html = "<h3 style=\"margin:0 0 10px;color:var(--primary-dark);\">Top 10 produits</h3><table class=\"table\"><thead><tr><th>#</th><th>Produit</th><th>Qte</th><th>Montant</th></tr></thead><tbody>";
            top.forEach((p, i) => { html += "<tr><td>" + (i+1) + "</td><td>" + p.nom + "</td><td>" + p.qte + "</td><td>" + p.montant.toFixed(0) + " Fc</td></tr>"; });
            html += "</tbody></table>";
            container.innerHTML = html;
        }

        async function chargerPerformanceAssistants(dateDebut, dateFin) {
            let q = dbCloud.from("tickets").select("*").eq("statut", "VALIDE");
            if (dateDebut) q = q.gte("date", dateDebut);
            if (dateFin) q = q.lte("date", dateFin);
            const { data: tickets, error } = await q;
            if (error) { console.error(error); const c=document.getElementById("assistant-performance-summary"); if(c)c.innerHTML=`<p style="color:#dc2626;text-align:center;">Impossible de charger les performances : ${error.message}</p>`; return; }
            const parAssistant = {};
            (tickets||[]).forEach(t => {
                if (!parAssistant[t.assistant]) parAssistant[t.assistant] = { nb:0, montant:0, benefice:0, articles:0 };
                parAssistant[t.assistant].nb++;
                parAssistant[t.assistant].montant += nombre(t.montant_total);
                parAssistant[t.assistant].benefice += nombre(t.benefice_total);
                parAssistant[t.assistant].articles += nombre(t.nb_articles);
            });
            const liste = Object.entries(parAssistant).sort((a,b) => b[1].montant - a[1].montant);
            const container = document.getElementById("assistant-performance-summary");
            if (!container) return;
            if (liste.length === 0) { container.innerHTML = "<p style=\"color:#718096;text-align:center;\">Aucune donnee.</p>"; return; }
            let html = "<h3 style=\"margin:0 0 10px;color:var(--primary-dark);\">Performance des assistants</h3><table class=\"table\"><thead><tr><th>Assistant</th><th>Tickets</th><th>Articles</th><th>Montant</th><th>Benefice</th></tr></thead><tbody>";
            liste.forEach(([nom, d]) => { html += "<tr><td><b>" + nom + "</b></td><td>" + d.nb + "</td><td>" + d.articles + "</td><td>" + d.montant.toFixed(0) + " Fc</td><td style=\"color:#16a34a;\">" + d.benefice.toFixed(0) + " Fc</td></tr>"; });
            html += "</tbody></table>";
            container.innerHTML = html;
        }

        async function chargerGraphiqueVentes(tickets) {
            const container = document.getElementById("sales-chart");
            if (!container) return;
            const parDate = {};
            tickets.forEach(t => { parDate[t.date] = (parDate[t.date]||0) + nombre(t.montant_total); });
            const dates = Object.keys(parDate).sort();
            if (dates.length === 0) { container.innerHTML = "<p style=\"color:#718096;text-align:center;\">Aucune donnee.</p>"; return; }
            const maxVal = Math.max(...Object.values(parDate));
            let html = "<h3 style=\"margin:0 0 10px;color:var(--primary-dark);\">Ventes par jour</h3>";
            html += "<div style=\"display:flex;align-items:flex-end;gap:4px;height:120px;padding:10px 0;\">";
            dates.forEach(d => {
                const val = parDate[d];
                const hauteur = maxVal > 0 ? (val / maxVal * 100) : 0;
                const jour = d.split("-").reverse().slice(0,2).join("/");
                html += "<div style=\"flex:1;display:flex;flex-direction:column;align-items:center;\"><div style=\"width:100%;background:linear-gradient(180deg,#10b981,#059669);border-radius:4px 4px 0 0;height:" + hauteur + "%;min-height:4px;\"></div><div style=\"font-size:9px;color:#666;margin-top:4px;\">" + jour + "</div></div>";
            });
            html += "</div>";
            container.innerHTML = html;
        }

        async function chargerSynthesePeriode(tickets, periode) {
            const container = document.getElementById("sales-period-summary");
            if (!container) return;
            const nbTickets = tickets.length;
            const totalMontant = tickets.reduce((s,t) => s + nombre(t.montant_total), 0);
            const totalBenefice = tickets.reduce((s,t) => s + nombre(t.benefice_total), 0);
            const panierMoyen = nbTickets > 0 ? totalMontant / nbTickets : 0;
            const nbJours = periode === "semaine" ? 7 : 30;
            const moyenneJour = totalMontant / nbJours;
            let html = "<h3 style=\"margin:0 0 10px;color:var(--primary-dark);\">Synthese de la periode</h3>";
            html += "<div style=\"display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;\">";
            html += "<div style=\"text-align:center;padding:10px;background:#f0fdf4;border-radius:8px;\"><div style=\"font-size:11px;color:#666;\">Panier moyen</div><div style=\"font-size:18px;font-weight:bold;color:#16a34a;\">" + panierMoyen.toFixed(0) + " Fc</div></div>";
            html += "<div style=\"text-align:center;padding:10px;background:#eff6ff;border-radius:8px;\"><div style=\"font-size:11px;color:#666;\">Moyenne / jour</div><div style=\"font-size:18px;font-weight:bold;color:#2563eb;\">" + moyenneJour.toFixed(0) + " Fc</div></div>";
            html += "<div style=\"text-align:center;padding:10px;background:#fef3c7;border-radius:8px;\"><div style=\"font-size:11px;color:#666;\">Tickets / jour</div><div style=\"font-size:18px;font-weight:bold;color:#b45309;\">" + (nbTickets/nbJours).toFixed(1) + "</div></div>";
            html += "</div>";
            container.innerHTML = html;
        }

        function initialiserDateRapportJournalier(){
            const el=document.getElementById('rapport-journalier-date');
            if(el && !el.value)el.value=new Date().toISOString().slice(0,10);
        }
        async function chargerRapportJournalier(){
            try{
                initialiserDateRapportJournalier();
                const dateRapport=document.getElementById('rapport-journalier-date')?.value||new Date().toISOString().slice(0,10);
                const {data,error}=await dbCloud.rpc('get_rapport_journalier',{p_date:dateRapport});
                if(error)throw error;
                rapportJournalierCache=data;
                const el=document.getElementById('rapport-journalier-preview');
                if(!el)return;
                const v=data.ventes||{}, c=data.tresorerie||{}, p=data.paiements||{};
                const money=x=>Number(x||0).toLocaleString('fr-FR')+' Fc';
                el.innerHTML=`<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px;"><div style="padding:10px;background:white;border-radius:8px;"><small>CA brut</small><br><b>${money(v.ca_brut)}</b></div><div style="padding:10px;background:white;border-radius:8px;"><small>Annulations</small><br><b style="color:#b91c1c;">-${money(v.annulations)}</b></div><div style="padding:10px;background:white;border-radius:8px;"><small>CA net</small><br><b>${money(v.ca_net)}</b></div><div style="padding:10px;background:white;border-radius:8px;"><small>Bénéfice</small><br><b>${money(v.benefice_net)}</b></div><div style="padding:10px;background:white;border-radius:8px;"><small>Solde ouverture</small><br><b>${money(c.solde_ouverture)}</b></div><div style="padding:10px;background:white;border-radius:8px;"><small>Solde clôture</small><br><b>${money(c.solde_cloture)}</b></div></div><div style="margin-top:10px;padding:10px;background:white;border-radius:8px;"><b>Paiements :</b> Espèces ${money(p.ESPECES)} · Mobile Money ${money(p.MOBILE_MONEY)} · Carte ${money(p.CARTE)} · Crédit ${money(p.CREDIT)}<br><b>Remboursements :</b> ${money(c.remboursements)} · <b>Dépenses :</b> ${money(c.depenses)} · <b>Tickets annulés :</b> ${v.tickets_annules||0}</div>`;
                return data;
            }catch(e){console.error(e);const el=document.getElementById('rapport-journalier-preview');if(el)el.innerHTML=`<span style="color:#b91c1c;">Erreur : ${e.message}</span>`;throw e;}
        }
        async function imprimerRapportJournalier(){
            try{
                const data=rapportJournalierCache||await chargerRapportJournalier();
                const dateRapport=document.getElementById('rapport-journalier-date')?.value||data.date||new Date().toISOString().slice(0,10);
                const v=data.ventes||{}, c=data.tresorerie||{}, p=data.paiements||{}, mouvements=data.mouvements||[];
                const w=window.open('','_blank'); if(!w)throw new Error('La fenêtre d’impression a été bloquée par le navigateur.');
                const money=x=>Number(x||0).toLocaleString('fr-FR')+' Fc';
                w.document.write(`<html><head><title>Rapport journalier ${dateRapport}</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#172033}h1{margin-bottom:4px}h2{margin-top:24px;border-bottom:1px solid #ddd;padding-bottom:6px}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.box{border:1px solid #ddd;border-radius:8px;padding:10px}.value{font-size:18px;font-weight:800;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border:1px solid #ddd;padding:7px;text-align:left}th{background:#f3f4f6}.negative{color:#b91c1c}.positive{color:#15803d}@media print{button{display:none}}</style></head><body><h1>Rapport journalier — ${new Date(dateRapport+'T00:00:00').toLocaleDateString('fr-FR')}</h1><div>PharmaSys · généré le ${new Date().toLocaleString('fr-FR')}</div><h2>Ventes</h2><div class='grid'><div class='box'>CA brut<div class='value'>${money(v.ca_brut)}</div></div><div class='box'>Annulations<div class='value negative'>-${money(v.annulations)}</div></div><div class='box'>CA net<div class='value'>${money(v.ca_net)}</div></div><div class='box'>Bénéfice net<div class='value'>${money(v.benefice_net)}</div></div><div class='box'>Tickets validés<div class='value'>${v.tickets||0}</div></div><div class='box'>Tickets annulés<div class='value'>${v.tickets_annules||0}</div></div></div><h2>Trésorerie</h2><div class='grid'><div class='box'>Ouverture<div class='value'>${money(c.solde_ouverture)}</div></div><div class='box'>Entrées<div class='value positive'>+${money(c.entrees)}</div></div><div class='box'>Sorties<div class='value negative'>-${money(c.sorties)}</div></div><div class='box'>Remboursements<div class='value negative'>-${money(c.remboursements)}</div></div><div class='box'>Dépenses<div class='value negative'>-${money(c.depenses)}</div></div><div class='box'>Solde clôture<div class='value'>${money(c.solde_cloture)}</div></div></div><h2>Paiements</h2><table><tr><th>Mode</th><th>Montant</th></tr>${Object.entries(p).map(([k,val])=>`<tr><td>${k.replace('_',' ')}</td><td>${money(val)}</td></tr>`).join('')}</table><h2>Mouvements caisse</h2><table><tr><th>Heure</th><th>Nature</th><th>Mode</th><th>Montant</th><th>Motif</th><th>Utilisateur</th></tr>${mouvements.map(m=>`<tr><td>${new Date(m.created_at).toLocaleTimeString('fr-FR')}</td><td>${m.nature||''}</td><td>${m.mode||''}</td><td class='${m.type==='ENTREE'?'positive':'negative'}'>${m.type==='ENTREE'?'+':'-'}${money(m.montant)}</td><td>${m.motif||''}</td><td>${m.assistant||''}</td></tr>`).join('')}</table></body></html>`);
                w.document.close(); w.focus(); setTimeout(()=>w.print(),250);
            }catch(e){console.error(e);alert('Impossible de générer le rapport journalier : '+e.message);}
        }

        async function migrerAnciennesVentesVersTickets() {
            if (!confirm("Migrer les anciennes ventes vers le systeme de tickets ?")) return;
            try {
                const { data: anciennes, error } = await dbCloud.from("historique_ventes").select("*").eq("statut", "VALIDE");
                if (error) throw error;
                let compteur = 0;
                const ticketsExistants = new Set();
                (anciennes||[]).forEach(v => {
                    const prefix = v.id.split("-")[0];
                    if (prefix && prefix.startsWith("TK")) ticketsExistants.add(prefix);
                });
                for (const v of (anciennes||[])) {
                    const prefix = v.id.split("-")[0];
                    if (!prefix || !prefix.startsWith("TK") || ticketsExistants.has(prefix)) continue;
                    await dbCloud.from("tickets").insert([{ id:prefix, date:v.date, heure:v.heure||"", assistant:v.assistant, assistant_id:v.assistant_id, nb_articles:nombre(v.quantite), montant_total:nombre(v.total), benefice_total:nombre(v.profit), statut:"VALIDE", tenant_id:TENANT_ID }]);
                    ticketsExistants.add(prefix);
                    compteur++;
                }
                alert(compteur + " tickets crees.");
            } catch (e) { console.error(e); alert("Erreur : " + e.message); }
        }

        async function chargerNotifications(force=false){
            if(!dbCloud || !utilisateurConnecte || !['admin','Administrateur','responsable','pharmacien'].includes(utilisateurConnecte.role)) return;
            try{
                const {data,error}=await dbCloud.from('notifications').select('*').order('created_at',{ascending:false}).limit(50);
                if(error) throw error;
                const arr=data||[], unread=arr.filter(n=>!n.lu).length;
                const previousUnread=lastNotificationCount;
                lastNotificationCount=unread;
                const btn=document.getElementById('btn-notifications'), count=document.getElementById('notification-count');
                if(btn)btn.style.display='block'; if(count)count.textContent=unread;
                const el=document.getElementById('notifications-list');
                if(el)el.innerHTML=arr.length?arr.map(n=>`<div style="padding:11px;border-bottom:1px solid #e5e7eb;background:${n.lu?'#fff':'#eff6ff'};border-radius:8px;margin-bottom:6px;"><div style="display:flex;justify-content:space-between;gap:8px;"><b>${n.niveau==='CRITIQUE'?'🔴':n.niveau==='IMPORTANT'?'🟠':'🟢'} ${n.titre}</b><small>${new Date(n.created_at).toLocaleString('fr-FR')}</small></div><div style="margin-top:4px;">${n.message}</div><small style="color:#64748b;">Action par : ${n.utilisateur_nom||'Système'}</small></div>`).join(''):'<p style="padding:15px;color:#64748b;text-align:center;">Aucune notification.</p>';
                if(unread>0 && force===false && 'Notification' in window && Notification.permission==='granted' && unread>0 && unread>previousUnread){ new Notification('PharmaSys',{body:`${unread} notification(s) à consulter.`}); }
            }catch(e){console.warn('Notifications:',e.message)}
        }
        function ouvrirNotifications(){const m=document.getElementById('notifications-modal');if(m)m.style.display='block';chargerNotifications(true)}
        function fermerNotifications(){const m=document.getElementById('notifications-modal');if(m)m.style.display='none'}
        async function marquerNotificationsLues(){if(!dbCloud)return;try{await dbCloud.rpc('marquer_notifications_lues');await chargerNotifications(true)}catch(e){console.warn(e)}}
        function demarrerNotifications(){if(!rolePeutGerer())return;chargerNotifications(true);if(notificationTimer)clearInterval(notificationTimer);notificationTimer=setInterval(()=>chargerNotifications(false),15000);if('Notification' in window && Notification.permission==='default') Notification.requestPermission().catch(()=>{});}

        let deferredInstallPrompt = null;
        function estDejaInstallee(){ return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true; }
        function mettreAJourBoutonInstallation(){ const b=document.getElementById('btn-install-app'); if(!b)return; b.style.display=(deferredInstallPrompt&&!estDejaInstallee())?'block':'none'; }
        async function installerApplication(){
            if(!deferredInstallPrompt){ alert('L installation sera proposée automatiquement lorsque le navigateur la rendra disponible.'); return; }
            const promptEvent=deferredInstallPrompt; deferredInstallPrompt=null; mettreAJourBoutonInstallation();
            try{ await promptEvent.prompt(); await promptEvent.userChoice; }catch(e){console.warn('Installation PWA:',e)}
        }
        function initialiserPWA(){
            if('serviceWorker' in navigator){ navigator.serviceWorker.register('./sw.js').catch(e=>console.warn('Service Worker:',e)); }
            window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;mettreAJourBoutonInstallation();});
            window.addEventListener('appinstalled',()=>{deferredInstallPrompt=null;mettreAJourBoutonInstallation();});
            mettreAJourBoutonInstallation();
        }

        async function initApp() {
            const main = document.querySelector(".container");
            const nav = document.getElementById("navigation-bar");
            const onboarding = document.getElementById("onboarding-screen");
            const login = document.getElementById("login-screen");
            if (main) main.style.display = "none";
            if (nav) nav.style.display = "none";
            if (onboarding) onboarding.style.display = "none";
            if (login) login.style.display = "none";
            const hasConfig = initSupabaseClient();
            if (!hasConfig) {
                if (onboarding) onboarding.style.display = "block";
                return;
            }
            document.getElementById("login-tenant-name").innerText = TENANT_NAME;
            document.getElementById("login-screen").style.display = "block";
            const storedSession = localStorage.getItem("pharma_user_session");
            const storedToken = localStorage.getItem("pharma_session_token");
            if (storedSession && storedToken) {
                // Validate the session token server-side before trusting it
                try {
                    const { data: valResult, error: valErr } = await dbCloud.rpc("validate_session", { p_token: storedToken });
                    if (valErr) throw valErr;
                    const parsed = typeof valResult === "string" ? JSON.parse(valResult) : valResult;
                    if (parsed && parsed.success) {
                        const sess = parsed.session;
                        utilisateurConnecte = { id: sess.user_id, nom: sess.nom, code: sess.code, role: sess.role, actif: true, tenant_id: sess.tenant_id };
                        initSupabaseClient(storedToken);
                        document.getElementById("login-screen").style.display = "none";
                        document.querySelector(".container").style.display = "block";
                        document.getElementById("navigation-bar").style.display = "flex";
                        document.getElementById("btn-logout-ui").style.display = "block";
                        document.getElementById("role-text").innerText = utilisateurConnecte.nom + " (" + ({admin:'Administrateur',assistant:'Assistant',caissier:'Caissier',pharmacien:'Pharmacien',responsable:'Responsable',lecture:'Consultation'}[utilisateurConnecte.role] || utilisateurConnecte.role) + ")";
                        if (rolePeutGerer()) {
                            document.getElementById("tab-admin-nav").style.display = "flex";
                            const astHint = document.getElementById("ast-click-hint"); if (astHint) astHint.style.display = "block";
                        } else {
                            document.getElementById("tab-admin-nav").style.display = "none";
                            const astHint = document.getElementById("ast-click-hint"); if (astHint) astHint.style.display = "none";
                        }
                        switchScreen(rolePeutGerer() ? "admin" : "assistant");
                        await chargerDonnees();
                        demarrerNotifications();
                        if(reseauDisponible()) synchroniserFileAttente();
                    } else {
                        // Session expired or invalid — clean up
                        localStorage.removeItem("pharma_user_session");
                        localStorage.removeItem("pharma_session_token");
                        initSupabaseClient();
                    }
                } catch(e) {
                    console.warn("Session validation failed:", e.message);
                    const validatedAt=Number(localStorage.getItem("pharma_session_validated_at")||0);
                    if(!reseauDisponible() && validatedAt && Date.now()-validatedAt < 24*60*60*1000){
                        try{
                            utilisateurConnecte=JSON.parse(storedSession);
                            initSupabaseClient(storedToken);
                            document.getElementById("login-screen").style.display="none";
                            document.querySelector(".container").style.display="block";
                            document.getElementById("navigation-bar").style.display="flex";
                            document.getElementById("btn-logout-ui").style.display="block";
                            document.getElementById("role-text").innerText=utilisateurConnecte.nom+" (mode hors-ligne)";
                            switchScreen(rolePeutGerer()?"admin":"assistant");
                            await restaurerCacheLocal();
                        }catch(_){localStorage.removeItem("pharma_user_session");localStorage.removeItem("pharma_session_token");}
                    } else {
                        localStorage.removeItem("pharma_user_session");
                        localStorage.removeItem("pharma_session_token");
                        localStorage.removeItem("pharma_session_validated_at");
                        initSupabaseClient();
                    }
                }
            }
            await migrerAncienneFileAttente();
            await chargerFileOffline();
            if (reseauDisponible()) synchroniserFileAttente();
            setConnectionStatus(reseauDisponible() ? "online" : "offline");
            await chargerInfosPharmacie();
            chargerNomPharmacie();
        }

        window.addEventListener("DOMContentLoaded", function() {
            initialiserPWA();
            mettreAJourBoutonModeHorsLigne();
            setTimeout(actualiserDiagnosticReseau, 1200);
            const toggleBtn = document.getElementById("toggle-login-code");
            if (toggleBtn) {
                toggleBtn.addEventListener("click", function() {
                    const input = document.getElementById("login-code");
                    input.type = input.type === "password" ? "text" : "password";
                });
            }
            const toggleUserCode = document.getElementById("toggle-user-code");
            if (toggleUserCode) {
                toggleUserCode.addEventListener("click", function() {
                    const input = document.getElementById("user-code");
                    input.type = input.type === "password" ? "text" : "password";
                });
            }
            initApp();
        });
    